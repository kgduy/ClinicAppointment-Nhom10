import React from 'react';
import { useState } from 'react';
import Header from './components/Header';
import Landing from './pages/Landing';
import PatientPortal from './pages/PatientPortal';
import DoctorPortal from './pages/DoctorPortal';
import AdminPortal from './pages/AdminPortal';
import type { Role } from './data/mockData';

type Portal = Role | 'landing';

export default function App() {
  const [activePortal, setActivePortal] = useState<Portal>('landing');
  const [patientLoggedIn, setPatientLoggedIn] = useState(false);
  const [doctorLoggedIn, setDoctorLoggedIn] = useState(false);
  const [adminLoggedIn, setAdminLoggedIn] = useState(false);

  const handleLogout = (role: Role) => {
    if (role === 'patient') setPatientLoggedIn(false);
    if (role === 'doctor') setDoctorLoggedIn(false);
    if (role === 'admin') setAdminLoggedIn(false);
  };

  return (
    <div className="min-h-screen" style={{ background: 'var(--color-surface)' }}>
      <Header
        activePortal={activePortal}
        setActivePortal={setActivePortal}
        patientLoggedIn={patientLoggedIn}
        doctorLoggedIn={doctorLoggedIn}
        adminLoggedIn={adminLoggedIn}
        onLogout={handleLogout}
      />

      {activePortal === 'landing' && (
        <Landing setActivePortal={setActivePortal} />
      )}

      {activePortal === 'patient' && (
        <PatientPortal
          loggedIn={patientLoggedIn}
          onLogin={() => setPatientLoggedIn(true)}
        />
      )}

      {activePortal === 'doctor' && (
        <DoctorPortal
          loggedIn={doctorLoggedIn}
          onLogin={() => setDoctorLoggedIn(true)}
        />
      )}

      {activePortal === 'admin' && (
        <AdminPortal
          loggedIn={adminLoggedIn}
          onLogin={() => setAdminLoggedIn(true)}
        />
      )}
    </div>
  );
}
