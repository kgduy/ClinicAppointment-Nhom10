import React from 'react';
// ... các dòng code import khác (như lucide-react, v.v.)
import { Role } from '../data/mockData';

interface HeaderProps {
  activePortal: Role | 'landing';
  setActivePortal: (p: Role | 'landing') => void;
  patientLoggedIn: boolean;
  doctorLoggedIn: boolean;
  adminLoggedIn: boolean;
  onLogout: (role: Role) => void;
}

export default function Header({ activePortal, setActivePortal, patientLoggedIn, doctorLoggedIn, adminLoggedIn, onLogout }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-white border-b" style={{ borderColor: 'var(--color-border)' }}>
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <button onClick={() => setActivePortal('landing')} className="flex items-center gap-2.5 hover:opacity-80 transition-opacity">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-sm font-bold"
            style={{ background: 'linear-gradient(135deg, var(--color-primary), var(--color-primary-light))' }}>
            P
          </div>
          <div>
            <div className="font-display font-semibold text-base leading-tight" style={{ color: 'var(--color-primary)' }}>
              PhòngKhám+
            </div>
            <div className="text-xs" style={{ color: 'var(--color-ink-3)', fontFamily: 'var(--font-mono)' }}>
              Đặt lịch trực tuyến
            </div>
          </div>
        </button>

        {/* Nav */}
        <nav className="hidden md:flex items-center gap-1">
          {([
            { key: 'landing', label: 'Trang chủ' },
            { key: 'patient', label: 'Bệnh nhân' },
            { key: 'doctor', label: 'Bác sĩ' },
            { key: 'admin', label: 'Quản trị' },
          ] as const).map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setActivePortal(key)}
              className="px-4 py-2 rounded-lg text-sm font-medium transition-all"
              style={{
                background: activePortal === key ? 'var(--color-primary-50)' : 'transparent',
                color: activePortal === key ? 'var(--color-primary)' : 'var(--color-ink-2)',
              }}
            >
              {label}
            </button>
          ))}
        </nav>

        {/* Auth status */}
        <div className="flex items-center gap-2 text-xs" style={{ fontFamily: 'var(--font-mono)', color: 'var(--color-ink-3)' }}>
          {patientLoggedIn && activePortal === 'patient' && (
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline">Lê Văn Cường</span>
              <button onClick={() => onLogout('patient')} className="px-3 py-1.5 rounded-lg border text-xs hover:bg-red-50 transition-colors"
                style={{ borderColor: 'var(--color-border)', color: 'var(--color-danger)' }}>Đăng xuất</button>
            </div>
          )}
          {doctorLoggedIn && activePortal === 'doctor' && (
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline">BS. Nguyễn Văn An</span>
              <button onClick={() => onLogout('doctor')} className="px-3 py-1.5 rounded-lg border text-xs hover:bg-red-50 transition-colors"
                style={{ borderColor: 'var(--color-border)', color: 'var(--color-danger)' }}>Đăng xuất</button>
            </div>
          )}
          {adminLoggedIn && activePortal === 'admin' && (
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline">Admin Hà</span>
              <button onClick={() => onLogout('admin')} className="px-3 py-1.5 rounded-lg border text-xs hover:bg-red-50 transition-colors"
                style={{ borderColor: 'var(--color-border)', color: 'var(--color-danger)' }}>Đăng xuất</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
