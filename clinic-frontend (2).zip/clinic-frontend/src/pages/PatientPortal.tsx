import React from 'react';
// ... các dòng code tiếp theo
import { useState } from 'react';
import { doctors, specialties, appointments, timeSlots, formatCurrency, formatDate, statusLabel, statusClass, services } from '../data/mockData';

type PatientView = 'login' | 'register' | 'home' | 'find-doctor' | 'book' | 'appointments' | 'profile';

interface PatientPortalProps {
  loggedIn: boolean;
  onLogin: () => void;
}

type BookStep = 1 | 2 | 3 | 4;

export default function PatientPortal({ loggedIn, onLogin }: PatientPortalProps) {
  const [view, setView] = useState<PatientView>(loggedIn ? 'home' : 'login');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [bookStep, setBookStep] = useState<BookStep>(1);
  const [selectedDoctor, setSelectedDoctor] = useState(doctors[0]);
  const [selectedDate, setSelectedDate] = useState('2026-09-22');
  const [selectedSlot, setSelectedSlot] = useState('');
  const [bookType, setBookType] = useState<'in-person' | 'online'>('in-person');
  const [bookReason, setBookReason] = useState('');
  const [bookSymptoms, setBookSymptoms] = useState('');
  const [bookDone, setBookDone] = useState(false);
  const [filterSpecialty, setFilterSpecialty] = useState('');
  const [searchDoc, setSearchDoc] = useState('');
  const [showForgot, setShowForgot] = useState(false);

  const myAppointments = appointments.filter(a => a.patientId === 'p1');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
    setView('home');
  };

  const handleBookDoctor = (d: typeof doctors[0]) => {
    setSelectedDoctor(d);
    setBookStep(1);
    setBookDone(false);
    setSelectedSlot('');
    setBookReason('');
    setBookSymptoms('');
    setView('book');
  };

  const filteredDocs = doctors.filter(d => {
    const q = searchDoc.toLowerCase();
    return (!q || d.name.toLowerCase().includes(q) || d.specialty.toLowerCase().includes(q))
      && (!filterSpecialty || d.specialtyId === filterSpecialty);
  });

  if (!loggedIn && view !== 'register') {
    return (
      <div className="min-h-screen flex items-center justify-center px-4 py-12" style={{ background: 'var(--color-surface-2)' }}>
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4"
              style={{ background: 'linear-gradient(135deg, var(--color-primary-dark), var(--color-primary-light))' }}>P</div>
            <h1 className="font-display text-2xl font-semibold mb-1">Đăng nhập bệnh nhân</h1>
            <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>Quản lý lịch khám và hồ sơ sức khỏe</p>
          </div>

          {showForgot ? (
            <div className="bg-white rounded-2xl border p-8" style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-elevated)' }}>
              <h2 className="font-semibold mb-4">Quên mật khẩu</h2>
              <p className="text-sm mb-4" style={{ color: 'var(--color-ink-3)' }}>Nhập email để nhận link đặt lại mật khẩu</p>
              <input className="w-full px-4 py-3 rounded-xl border text-sm outline-none mb-4"
                style={{ borderColor: 'var(--color-border)' }} placeholder="Email của bạn" type="email" />
              <button className="w-full py-3 rounded-xl text-white font-semibold text-sm mb-3"
                style={{ background: 'var(--color-primary)' }} onClick={() => setShowForgot(false)}>
                Gửi link đặt lại
              </button>
              <button className="w-full text-sm py-2" style={{ color: 'var(--color-primary)' }} onClick={() => setShowForgot(false)}>
                ← Quay lại đăng nhập
              </button>
            </div>
          ) : (
            <form onSubmit={handleLogin} className="bg-white rounded-2xl border p-8 space-y-4"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-elevated)' }}>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-ink-2)' }}>Email</label>
                <input value={loginEmail} onChange={e => setLoginEmail(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all"
                  style={{ borderColor: 'var(--color-border)' }}
                  placeholder="cuong.le@email.com" type="email"
                  onFocus={e => e.currentTarget.style.borderColor = 'var(--color-primary)'}
                  onBlur={e => e.currentTarget.style.borderColor = 'var(--color-border)'} />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-ink-2)' }}>Mật khẩu</label>
                <input value={loginPass} onChange={e => setLoginPass(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all"
                  style={{ borderColor: 'var(--color-border)' }}
                  placeholder="••••••••" type="password"
                  onFocus={e => e.currentTarget.style.borderColor = 'var(--color-primary)'}
                  onBlur={e => e.currentTarget.style.borderColor = 'var(--color-border)'} />
              </div>
              <button type="button" className="text-sm" style={{ color: 'var(--color-primary)' }} onClick={() => setShowForgot(true)}>
                Quên mật khẩu?
              </button>
              <button type="submit" className="w-full py-3 rounded-xl text-white font-semibold text-sm transition-all hover:opacity-90"
                style={{ background: 'var(--color-primary)' }}>
                Đăng nhập
              </button>
              <div className="text-center text-sm pt-2" style={{ color: 'var(--color-ink-3)' }}>
                Chưa có tài khoản?{' '}
                <button type="button" className="font-medium" style={{ color: 'var(--color-primary)' }}
                  onClick={() => setView('register')}>
                  Đăng ký ngay
                </button>
              </div>
              <div className="relative flex items-center gap-3 py-1">
                <div className="flex-1 h-px" style={{ background: 'var(--color-border)' }} />
                <span className="text-xs" style={{ color: 'var(--color-ink-4)' }}>hoặc thử demo</span>
                <div className="flex-1 h-px" style={{ background: 'var(--color-border)' }} />
              </div>
              <button type="button" onClick={() => { onLogin(); setView('home'); }}
                className="w-full py-2.5 rounded-xl border text-sm font-medium transition-all hover:bg-gray-50"
                style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>
                Đăng nhập demo (không cần mật khẩu)
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  if (view === 'register') {
    return (
      <div className="min-h-screen flex items-center justify-center px-4 py-12" style={{ background: 'var(--color-surface-2)' }}>
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="font-display text-2xl font-semibold mb-1">Đăng ký tài khoản</h1>
            <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>Miễn phí và nhanh chóng</p>
          </div>
          <div className="bg-white rounded-2xl border p-8 space-y-4"
            style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-elevated)' }}>
            {[
              { label: 'Họ và tên', placeholder: 'Lê Văn Cường', type: 'text' },
              { label: 'Số điện thoại', placeholder: '0901 234 567', type: 'tel' },
              { label: 'Email', placeholder: 'cuong.le@email.com', type: 'email' },
              { label: 'Mật khẩu', placeholder: '••••••••', type: 'password' },
              { label: 'Xác nhận mật khẩu', placeholder: '••••••••', type: 'password' },
            ].map(f => (
              <div key={f.label}>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-ink-2)' }}>{f.label}</label>
                <input type={f.type} placeholder={f.placeholder}
                  className="w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all"
                  style={{ borderColor: 'var(--color-border)' }}
                  onFocus={e => e.currentTarget.style.borderColor = 'var(--color-primary)'}
                  onBlur={e => e.currentTarget.style.borderColor = 'var(--color-border)'} />
              </div>
            ))}
            <button onClick={() => { onLogin(); setView('home'); }}
              className="w-full py-3 rounded-xl text-white font-semibold text-sm"
              style={{ background: 'var(--color-primary)' }}>
              Tạo tài khoản
            </button>
            <div className="text-center text-sm" style={{ color: 'var(--color-ink-3)' }}>
              Đã có tài khoản?{' '}
              <button className="font-medium" style={{ color: 'var(--color-primary)' }} onClick={() => setView('login')}>
                Đăng nhập
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Booking flow
  if (view === 'book') {
    if (bookDone) {
      return (
        <div className="min-h-screen flex items-center justify-center px-4" style={{ background: 'var(--color-surface-2)' }}>
          <div className="bg-white rounded-2xl border p-10 max-w-md w-full text-center"
            style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-elevated)' }}>
            <div className="w-16 h-16 rounded-full flex items-center justify-center text-3xl mx-auto mb-4"
              style={{ background: 'var(--color-primary-50)' }}>✅</div>
            <h2 className="font-display text-2xl font-semibold mb-2">Đặt lịch thành công!</h2>
            <p className="text-sm mb-6" style={{ color: 'var(--color-ink-3)' }}>
              Xác nhận sẽ được gửi đến email và SMS của bạn trong vài phút.
            </p>
            <div className="rounded-xl p-4 mb-6 text-left space-y-2" style={{ background: 'var(--color-surface-2)' }}>
              <div className="flex justify-between text-sm">
                <span style={{ color: 'var(--color-ink-3)' }}>Bác sĩ</span>
                <span className="font-medium">{selectedDoctor.name}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span style={{ color: 'var(--color-ink-3)' }}>Ngày</span>
                <span className="font-medium">{formatDate(selectedDate)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span style={{ color: 'var(--color-ink-3)' }}>Giờ</span>
                <span className="font-medium">{selectedSlot}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span style={{ color: 'var(--color-ink-3)' }}>Hình thức</span>
                <span className="font-medium">{bookType === 'in-person' ? 'Trực tiếp' : 'Online'}</span>
              </div>
              <div className="flex justify-between text-sm pt-2 border-t" style={{ borderColor: 'var(--color-border)' }}>
                <span style={{ color: 'var(--color-ink-3)' }}>Phí khám</span>
                <span className="font-semibold" style={{ color: 'var(--color-primary)' }}>{formatCurrency(selectedDoctor.price)}</span>
              </div>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setView('appointments')} className="flex-1 py-3 rounded-xl font-semibold text-sm text-white"
                style={{ background: 'var(--color-primary)' }}>
                Xem lịch của tôi
              </button>
              <button onClick={() => { setView('find-doctor'); setBookDone(false); }} className="flex-1 py-3 rounded-xl font-medium text-sm border"
                style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>
                Đặt thêm lịch
              </button>
            </div>
          </div>
        </div>
      );
    }

    const steps = ['Chọn ngày & giờ', 'Hình thức khám', 'Thông tin khám', 'Xác nhận'];
    return (
      <div className="min-h-screen py-8 px-4" style={{ background: 'var(--color-surface-2)' }}>
        <div className="max-w-2xl mx-auto">
          <button onClick={() => setView('find-doctor')} className="flex items-center gap-2 text-sm mb-6"
            style={{ color: 'var(--color-primary)' }}>
            ← Quay lại
          </button>

          {/* Progress */}
          <div className="flex items-center mb-8">
            {steps.map((s, i) => (
              <div key={i} className="flex items-center flex-1 last:flex-none">
                <div className="flex items-center gap-2">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-all`}
                    style={{
                      background: i + 1 < bookStep ? 'var(--color-success)' : i + 1 === bookStep ? 'var(--color-primary)' : 'var(--color-border)',
                      color: i + 1 <= bookStep ? 'white' : 'var(--color-ink-4)',
                    }}>
                    {i + 1 < bookStep ? '✓' : i + 1}
                  </div>
                  <span className="hidden sm:inline text-xs font-medium"
                    style={{ color: i + 1 === bookStep ? 'var(--color-ink)' : 'var(--color-ink-4)' }}>
                    {s}
                  </span>
                </div>
                {i < 3 && <div className="flex-1 h-px mx-3" style={{ background: i + 1 < bookStep ? 'var(--color-success)' : 'var(--color-border)' }} />}
              </div>
            ))}
          </div>

          {/* Doctor summary */}
          <div className="bg-white rounded-2xl border p-4 flex items-center gap-4 mb-6"
            style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
            <img src={selectedDoctor.photo} alt={selectedDoctor.name} className="w-14 h-14 rounded-xl object-cover" />
            <div>
              <h3 className="font-semibold" style={{ color: 'var(--color-ink)' }}>{selectedDoctor.name}</h3>
              <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>{selectedDoctor.specialty} · {selectedDoctor.branch}</p>
              <p className="text-sm font-semibold" style={{ color: 'var(--color-primary)' }}>{formatCurrency(selectedDoctor.price)}</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border p-6" style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
            {/* Step 1: Date & Time */}
            {bookStep === 1 && (
              <div className="animate-fade-in">
                <h2 className="font-display text-xl font-semibold mb-6">Chọn ngày & giờ khám</h2>
                <div className="mb-6">
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-ink-2)' }}>Ngày khám</label>
                  <div className="flex gap-2 flex-wrap">
                    {['2026-09-22', '2026-09-23', '2026-09-24', '2026-09-25', '2026-09-26'].map(d => {
                      const dt = new Date(d);
                      const days = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
                      return (
                        <button key={d} onClick={() => setSelectedDate(d)}
                          className="flex flex-col items-center px-4 py-3 rounded-xl border text-sm transition-all min-w-[68px]"
                          style={{
                            borderColor: selectedDate === d ? 'var(--color-primary)' : 'var(--color-border)',
                            background: selectedDate === d ? 'var(--color-primary-50)' : 'white',
                            color: selectedDate === d ? 'var(--color-primary)' : 'var(--color-ink-2)',
                          }}>
                          <span className="text-xs">{days[dt.getDay()]}</span>
                          <span className="font-semibold">{dt.getDate()}</span>
                          <span className="text-xs">{dt.toLocaleString('vi', { month: 'short' })}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-ink-2)' }}>
                    Khung giờ trống — {formatDate(selectedDate)}
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {timeSlots.map(s => (
                      <button key={s.id} disabled={!s.available} onClick={() => setSelectedSlot(s.time)}
                        className="py-2.5 rounded-lg text-sm font-medium border transition-all"
                        style={{
                          borderColor: selectedSlot === s.time ? 'var(--color-primary)' : !s.available ? 'transparent' : 'var(--color-border)',
                          background: selectedSlot === s.time ? 'var(--color-primary)' : !s.available ? 'var(--color-surface-2)' : 'white',
                          color: selectedSlot === s.time ? 'white' : !s.available ? 'var(--color-ink-4)' : 'var(--color-ink-2)',
                          cursor: s.available ? 'pointer' : 'not-allowed',
                        }}>
                        {s.time}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs mt-2" style={{ color: 'var(--color-ink-4)' }}>
                    Ô màu xám: đã đặt / không còn trống
                  </p>
                </div>
                <button disabled={!selectedSlot} onClick={() => setBookStep(2)}
                  className="mt-6 w-full py-3 rounded-xl font-semibold text-sm transition-all"
                  style={{
                    background: selectedSlot ? 'var(--color-primary)' : 'var(--color-surface-3)',
                    color: selectedSlot ? 'white' : 'var(--color-ink-4)',
                  }}>
                  Tiếp theo →
                </button>
              </div>
            )}

            {/* Step 2: Type */}
            {bookStep === 2 && (
              <div className="animate-fade-in">
                <h2 className="font-display text-xl font-semibold mb-6">Hình thức khám</h2>
                <div className="grid gap-4 mb-6">
                  {([
                    { key: 'in-person', icon: '🏥', title: 'Khám trực tiếp', desc: 'Đến phòng khám gặp bác sĩ trực tiếp. Khuyến nghị cho lần khám đầu.' },
                    { key: 'online', icon: '💻', title: 'Tư vấn online', desc: 'Video call với bác sĩ qua ứng dụng. Tiện lợi, không cần di chuyển.' },
                  ] as const).map(t => (
                    <button key={t.key} onClick={() => setBookType(t.key)}
                      className="flex items-start gap-4 p-4 rounded-xl border text-left transition-all"
                      style={{
                        borderColor: bookType === t.key ? 'var(--color-primary)' : 'var(--color-border)',
                        background: bookType === t.key ? 'var(--color-primary-50)' : 'white',
                      }}>
                      <span className="text-2xl">{t.icon}</span>
                      <div>
                        <div className="font-semibold text-sm mb-1" style={{ color: 'var(--color-ink)' }}>{t.title}</div>
                        <div className="text-sm" style={{ color: 'var(--color-ink-3)' }}>{t.desc}</div>
                      </div>
                      <div className="ml-auto flex-shrink-0 mt-0.5">
                        <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center"
                          style={{ borderColor: bookType === t.key ? 'var(--color-primary)' : 'var(--color-border)' }}>
                          {bookType === t.key && <div className="w-2.5 h-2.5 rounded-full" style={{ background: 'var(--color-primary)' }} />}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-medium mb-2" style={{ color: 'var(--color-ink-2)' }}>Dịch vụ</label>
                  <select className="w-full px-4 py-3 rounded-xl border text-sm outline-none"
                    style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>
                    {services.filter(s => s.specialtyId === selectedDoctor.specialtyId).map(s => (
                      <option key={s.id} value={s.id}>{s.name} — {formatCurrency(s.price)} ({s.duration} phút)</option>
                    ))}
                  </select>
                </div>

                <div className="flex gap-3">
                  <button onClick={() => setBookStep(1)} className="flex-1 py-3 rounded-xl border text-sm font-medium"
                    style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>← Quay lại</button>
                  <button onClick={() => setBookStep(3)} className="flex-1 py-3 rounded-xl text-white text-sm font-semibold"
                    style={{ background: 'var(--color-primary)' }}>Tiếp theo →</button>
                </div>
              </div>
            )}

            {/* Step 3: Reason */}
            {bookStep === 3 && (
              <div className="animate-fade-in">
                <h2 className="font-display text-xl font-semibold mb-6">Thông tin khám</h2>
                <div className="space-y-4 mb-6">
                  <div>
                    <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-ink-2)' }}>
                      Lý do khám <span style={{ color: 'var(--color-danger)' }}>*</span>
                    </label>
                    <input value={bookReason} onChange={e => setBookReason(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border text-sm outline-none transition-all"
                      style={{ borderColor: 'var(--color-border)' }}
                      placeholder="VD: Kiểm tra huyết áp định kỳ, khám sức khỏe tổng quát..."
                      onFocus={e => e.currentTarget.style.borderColor = 'var(--color-primary)'}
                      onBlur={e => e.currentTarget.style.borderColor = 'var(--color-border)'} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-ink-2)' }}>
                      Triệu chứng hiện tại
                    </label>
                    <textarea value={bookSymptoms} onChange={e => setBookSymptoms(e.target.value)} rows={4}
                      className="w-full px-4 py-3 rounded-xl border text-sm outline-none resize-none transition-all"
                      style={{ borderColor: 'var(--color-border)' }}
                      placeholder="Mô tả chi tiết các triệu chứng, thời gian xuất hiện, mức độ..."
                      onFocus={e => e.currentTarget.style.borderColor = 'var(--color-primary)'}
                      onBlur={e => e.currentTarget.style.borderColor = 'var(--color-border)'} />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-ink-2)' }}>
                      Đính kèm file (xét nghiệm, hình ảnh cũ)
                    </label>
                    <div className="border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all"
                      style={{ borderColor: 'var(--color-border)' }}>
                      <div className="text-2xl mb-2">📎</div>
                      <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>Kéo thả file hoặc nhấn để chọn</p>
                      <p className="text-xs mt-1" style={{ color: 'var(--color-ink-4)' }}>PDF, JPG, PNG — tối đa 10MB</p>
                    </div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setBookStep(2)} className="flex-1 py-3 rounded-xl border text-sm font-medium"
                    style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>← Quay lại</button>
                  <button disabled={!bookReason} onClick={() => setBookStep(4)}
                    className="flex-1 py-3 rounded-xl text-sm font-semibold transition-all"
                    style={{ background: bookReason ? 'var(--color-primary)' : 'var(--color-surface-3)', color: bookReason ? 'white' : 'var(--color-ink-4)' }}>
                    Tiếp theo →
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Confirm */}
            {bookStep === 4 && (
              <div className="animate-fade-in">
                <h2 className="font-display text-xl font-semibold mb-6">Xác nhận lịch khám</h2>
                <div className="rounded-xl p-5 space-y-3 mb-6" style={{ background: 'var(--color-surface-2)' }}>
                  {[
                    { label: 'Bác sĩ', value: selectedDoctor.name },
                    { label: 'Chuyên khoa', value: selectedDoctor.specialty },
                    { label: 'Cơ sở', value: selectedDoctor.branch },
                    { label: 'Ngày khám', value: formatDate(selectedDate) },
                    { label: 'Giờ khám', value: selectedSlot },
                    { label: 'Hình thức', value: bookType === 'in-person' ? 'Trực tiếp' : 'Online' },
                    { label: 'Lý do', value: bookReason },
                  ].map(r => (
                    <div key={r.label} className="flex justify-between text-sm gap-4">
                      <span style={{ color: 'var(--color-ink-3)' }}>{r.label}</span>
                      <span className="font-medium text-right" style={{ color: 'var(--color-ink)' }}>{r.value}</span>
                    </div>
                  ))}
                  <div className="flex justify-between text-sm pt-3 border-t font-semibold" style={{ borderColor: 'var(--color-border)' }}>
                    <span style={{ color: 'var(--color-ink-2)' }}>Phí khám (ước tính)</span>
                    <span style={{ color: 'var(--color-primary)' }}>{formatCurrency(selectedDoctor.price)}</span>
                  </div>
                </div>

                <div className="rounded-xl p-4 mb-6 text-sm flex items-start gap-3"
                  style={{ background: '#FEF3C7', color: '#92400E' }}>
                  <span className="text-lg flex-shrink-0">⚠️</span>
                  <p>Phí khám có thể thay đổi tùy theo dịch vụ phát sinh. Thanh toán tại quầy sau khi khám hoặc online qua ứng dụng.</p>
                </div>

                <div className="flex gap-3">
                  <button onClick={() => setBookStep(3)} className="flex-1 py-3 rounded-xl border text-sm font-medium"
                    style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>← Chỉnh sửa</button>
                  <button onClick={() => setBookDone(true)} className="flex-1 py-3 rounded-xl text-white text-sm font-semibold"
                    style={{ background: 'var(--color-primary)' }}>
                    ✅ Xác nhận đặt lịch
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: 'var(--color-surface-2)' }}>
      {/* Sidebar nav */}
      <div className="flex">
        <aside className="hidden md:flex flex-col w-56 min-h-screen bg-white border-r flex-shrink-0"
          style={{ borderColor: 'var(--color-border)' }}>
          <div className="p-4 border-b" style={{ borderColor: 'var(--color-border)' }}>
            <div className="flex items-center gap-3">
              <img src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=80&h=80&fit=crop"
                alt="avatar" className="w-10 h-10 rounded-full object-cover" />
              <div>
                <div className="font-semibold text-sm" style={{ color: 'var(--color-ink)' }}>Lê Văn Cường</div>
                <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>Bệnh nhân</div>
              </div>
            </div>
          </div>
          <nav className="flex-1 p-3 space-y-1">
            {([
              { key: 'home', icon: '🏠', label: 'Tổng quan' },
              { key: 'find-doctor', icon: '🔍', label: 'Tìm bác sĩ' },
              { key: 'appointments', icon: '📅', label: 'Lịch hẹn của tôi' },
              { key: 'profile', icon: '👤', label: 'Hồ sơ cá nhân' },
            ] as const).map(n => (
              <button key={n.key} onClick={() => setView(n.key)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-left transition-all"
                style={{
                  background: view === n.key ? 'var(--color-primary-50)' : 'transparent',
                  color: view === n.key ? 'var(--color-primary)' : 'var(--color-ink-2)',
                }}>
                <span>{n.icon}</span> {n.label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Mobile nav */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t z-40 flex"
          style={{ borderColor: 'var(--color-border)' }}>
          {([
            { key: 'home', icon: '🏠', label: 'Trang chủ' },
            { key: 'find-doctor', icon: '🔍', label: 'Tìm bác sĩ' },
            { key: 'appointments', icon: '📅', label: 'Lịch hẹn' },
            { key: 'profile', icon: '👤', label: 'Hồ sơ' },
          ] as const).map(n => (
            <button key={n.key} onClick={() => setView(n.key)}
              className="flex-1 flex flex-col items-center py-2 text-xs transition-all"
              style={{ color: view === n.key ? 'var(--color-primary)' : 'var(--color-ink-3)' }}>
              <span className="text-xl">{n.icon}</span>
              {n.label}
            </button>
          ))}
        </div>

        {/* Main content */}
        <main className="flex-1 p-4 md:p-8 pb-20 md:pb-8">
          {/* Home */}
          {view === 'home' && (
            <div className="animate-fade-in max-w-4xl">
              <h1 className="font-display text-2xl font-semibold mb-1">Xin chào, Cường 👋</h1>
              <p className="text-sm mb-6" style={{ color: 'var(--color-ink-3)' }}>Thứ Sáu, 19 tháng 9 năm 2026</p>

              {/* Upcoming appointment */}
              <div className="rounded-2xl p-6 mb-6 text-white relative overflow-hidden"
                style={{ background: 'linear-gradient(135deg, var(--color-primary-dark), var(--color-primary-light))' }}>
                <div className="absolute top-0 right-0 w-40 h-40 opacity-10 rounded-full"
                  style={{ background: 'white', transform: 'translate(20%, -20%)' }} />
                <div className="text-xs font-medium mb-3 opacity-80">Lịch khám sắp tới</div>
                <div className="flex items-center gap-3 mb-3">
                  <img src={doctors[0].photo} alt={doctors[0].name}
                    className="w-12 h-12 rounded-xl object-cover border-2 border-white border-opacity-30" />
                  <div>
                    <div className="font-semibold">{doctors[0].name}</div>
                    <div className="text-sm opacity-80">{doctors[0].specialty}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm opacity-90">
                  <span>📅 {formatDate('2026-09-19')}</span>
                  <span>🕘 09:00</span>
                  <span>🏥 Trực tiếp</span>
                </div>
                <div className="mt-4 flex gap-2">
                  <button className="px-4 py-2 rounded-lg text-xs font-medium"
                    style={{ background: 'white', color: 'var(--color-primary-dark)' }}>
                    Xem chi tiết
                  </button>
                  <button className="px-4 py-2 rounded-lg text-xs font-medium border border-white border-opacity-40 text-white">
                    Hủy lịch
                  </button>
                </div>
              </div>

              {/* Quick actions */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                {[
                  { icon: '📅', label: 'Đặt lịch mới', action: () => setView('find-doctor') },
                  { icon: '📋', label: 'Lịch sử khám', action: () => setView('appointments') },
                  { icon: '💊', label: 'Đơn thuốc', action: () => {} },
                  { icon: '📁', label: 'Hồ sơ bệnh', action: () => setView('profile') },
                ].map(a => (
                  <button key={a.label} onClick={a.action}
                    className="bg-white rounded-xl p-4 border flex flex-col items-center gap-2 transition-all hover:shadow-md text-center"
                    style={{ borderColor: 'var(--color-border)' }}>
                    <span className="text-2xl">{a.icon}</span>
                    <span className="text-xs font-medium" style={{ color: 'var(--color-ink-2)' }}>{a.label}</span>
                  </button>
                ))}
              </div>

              {/* Recent appointments */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="font-semibold" style={{ color: 'var(--color-ink)' }}>Lịch hẹn gần đây</h2>
                  <button className="text-sm" style={{ color: 'var(--color-primary)' }} onClick={() => setView('appointments')}>
                    Xem tất cả →
                  </button>
                </div>
                <div className="space-y-3">
                  {myAppointments.slice(0, 3).map(a => (
                    <div key={a.id} className="bg-white rounded-xl border p-4 flex items-center gap-4"
                      style={{ borderColor: 'var(--color-border)' }}>
                      <img src={doctors.find(d => d.id === a.doctorId)?.photo} alt={a.doctorName}
                        className="w-10 h-10 rounded-xl object-cover flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate" style={{ color: 'var(--color-ink)' }}>{a.doctorName}</div>
                        <div className="text-xs" style={{ color: 'var(--color-ink-3)' }}>{a.date} · {a.time}</div>
                      </div>
                      <span className={`px-2.5 py-1 rounded-lg text-xs font-medium flex-shrink-0 ${statusClass[a.status]}`}>
                        {statusLabel[a.status]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Find Doctor */}
          {view === 'find-doctor' && (
            <div className="animate-fade-in max-w-4xl">
              <h1 className="font-display text-2xl font-semibold mb-6">Tìm & đặt lịch bác sĩ</h1>
              <div className="flex flex-col sm:flex-row gap-3 mb-4">
                <div className="relative flex-1">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2">🔍</span>
                  <input value={searchDoc} onChange={e => setSearchDoc(e.target.value)}
                    className="w-full pl-11 pr-4 py-3 rounded-xl border text-sm outline-none"
                    style={{ borderColor: 'var(--color-border)', background: 'white' }}
                    placeholder="Tên bác sĩ, chuyên khoa..." />
                </div>
                <select value={filterSpecialty} onChange={e => setFilterSpecialty(e.target.value)}
                  className="px-4 py-3 rounded-xl border text-sm outline-none"
                  style={{ borderColor: 'var(--color-border)', background: 'white', minWidth: 180 }}>
                  <option value="">Tất cả chuyên khoa</option>
                  {specialties.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                {filteredDocs.map(doc => (
                  <div key={doc.id} className="bg-white rounded-2xl border p-5 transition-all hover:shadow-md"
                    style={{ borderColor: 'var(--color-border)' }}>
                    <div className="flex items-start gap-3 mb-3">
                      <img src={doc.photo} alt={doc.name} className="w-14 h-14 rounded-xl object-cover" />
                      <div className="flex-1">
                        <div className="font-semibold text-sm" style={{ color: 'var(--color-ink)' }}>{doc.name}</div>
                        <div className="text-xs" style={{ color: 'var(--color-ink-3)' }}>{doc.title}</div>
                        <div className="flex items-center gap-2 mt-1 text-xs" style={{ color: 'var(--color-ink-3)' }}>
                          <span>⭐ {doc.rating}</span>
                          <span>·</span>
                          <span>{doc.experience} năm KN</span>
                        </div>
                      </div>
                      <span className="text-sm font-semibold flex-shrink-0" style={{ color: 'var(--color-primary)' }}>
                        {formatCurrency(doc.price)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mb-3 text-xs" style={{ color: 'var(--color-ink-3)' }}>
                      <span>📍 {doc.branch}</span>
                    </div>
                    <button
                      disabled={!doc.available}
                      onClick={() => doc.available && handleBookDoctor(doc)}
                      className="w-full py-2.5 rounded-xl text-sm font-semibold transition-all"
                      style={{
                        background: doc.available ? 'var(--color-primary)' : 'var(--color-surface-3)',
                        color: doc.available ? 'white' : 'var(--color-ink-4)',
                      }}>
                      {doc.available ? 'Đặt lịch' : 'Không có lịch'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Appointments list */}
          {view === 'appointments' && (
            <div className="animate-fade-in max-w-4xl">
              <h1 className="font-display text-2xl font-semibold mb-6">Lịch hẹn của tôi</h1>
              <div className="space-y-4">
                {myAppointments.map(a => (
                  <div key={a.id} className="bg-white rounded-2xl border p-5"
                    style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                    <div className="flex items-start gap-4">
                      <img src={doctors.find(d => d.id === a.doctorId)?.photo} alt={a.doctorName}
                        className="w-12 h-12 rounded-xl object-cover flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 flex-wrap">
                          <div>
                            <div className="font-semibold" style={{ color: 'var(--color-ink)' }}>{a.doctorName}</div>
                            <div className="text-sm" style={{ color: 'var(--color-ink-3)' }}>{a.specialty}</div>
                          </div>
                          <span className={`px-2.5 py-1 rounded-lg text-xs font-medium flex-shrink-0 ${statusClass[a.status]}`}>
                            {statusLabel[a.status]}
                          </span>
                        </div>
                        <div className="flex flex-wrap gap-4 mt-3 text-sm" style={{ color: 'var(--color-ink-3)' }}>
                          <span>📅 {a.date}</span>
                          <span>🕐 {a.time}</span>
                          <span>{a.type === 'online' ? '💻 Online' : '🏥 Trực tiếp'}</span>
                          <span>📍 {a.branch}</span>
                        </div>
                        {a.reason && (
                          <div className="mt-2 text-sm" style={{ color: 'var(--color-ink-2)' }}>
                            <span style={{ color: 'var(--color-ink-4)' }}>Lý do: </span>{a.reason}
                          </div>
                        )}
                        {a.notes && (
                          <div className="mt-2 text-sm rounded-lg px-3 py-2" style={{ background: 'var(--color-surface-2)', color: 'var(--color-ink-2)' }}>
                            📋 Ghi chú BS: {a.notes}
                          </div>
                        )}
                        <div className="flex items-center justify-between mt-3">
                          <span className="font-semibold text-sm" style={{ color: 'var(--color-primary)' }}>
                            {formatCurrency(a.price)}
                          </span>
                          {(a.status === 'confirmed' || a.status === 'pending') && (
                            <div className="flex gap-2">
                              <button className="px-3 py-1.5 rounded-lg text-xs border transition-all hover:bg-orange-50"
                                style={{ borderColor: 'var(--color-border)', color: 'var(--color-warning)' }}>
                                Đổi lịch
                              </button>
                              <button className="px-3 py-1.5 rounded-lg text-xs border transition-all hover:bg-red-50"
                                style={{ borderColor: 'var(--color-border)', color: 'var(--color-danger)' }}>
                                Hủy lịch
                              </button>
                            </div>
                          )}
                          {a.status === 'done' && (
                            <button className="px-3 py-1.5 rounded-lg text-xs border"
                              style={{ borderColor: 'var(--color-border)', color: 'var(--color-accent)' }}>
                              ⭐ Đánh giá
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Profile */}
          {view === 'profile' && (
            <div className="animate-fade-in max-w-2xl">
              <h1 className="font-display text-2xl font-semibold mb-6">Hồ sơ cá nhân</h1>
              <div className="bg-white rounded-2xl border p-6 mb-6"
                style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                <div className="flex items-center gap-5 mb-6">
                  <img src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=80&h=80&fit=crop"
                    alt="avatar" className="w-20 h-20 rounded-2xl object-cover" />
                  <div>
                    <h2 className="font-display text-xl font-semibold">Lê Văn Cường</h2>
                    <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>Mã BN: #P001</p>
                    <button className="mt-2 px-3 py-1.5 rounded-lg text-xs border"
                      style={{ borderColor: 'var(--color-border)', color: 'var(--color-primary)' }}>
                      Đổi ảnh
                    </button>
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  {[
                    { label: 'Họ tên', value: 'Lê Văn Cường' },
                    { label: 'Ngày sinh', value: '15/03/1985' },
                    { label: 'Giới tính', value: 'Nam' },
                    { label: 'Nhóm máu', value: 'O+' },
                    { label: 'Điện thoại', value: '0901 234 567' },
                    { label: 'Email', value: 'cuong.le@email.com' },
                    { label: 'Địa chỉ', value: '12 Nguyễn Huệ, Q.1' },
                    { label: 'Người liên hệ', value: 'Lê Thị Hoa (vợ) — 0912 888 999' },
                  ].map(f => (
                    <div key={f.label}>
                      <label className="block text-xs mb-1" style={{ color: 'var(--color-ink-4)', fontFamily: 'var(--font-mono)' }}>{f.label}</label>
                      <input defaultValue={f.value} className="w-full px-3 py-2.5 rounded-lg border text-sm outline-none"
                        style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-2)' }} />
                    </div>
                  ))}
                </div>
                <button className="mt-5 px-5 py-2.5 rounded-xl text-sm font-semibold text-white"
                  style={{ background: 'var(--color-primary)' }}>
                  Lưu thay đổi
                </button>
              </div>

              <div className="bg-white rounded-2xl border p-6" style={{ borderColor: 'var(--color-border)' }}>
                <h3 className="font-semibold mb-4">Thông báo</h3>
                {[
                  { label: 'Nhắc lịch trước 24 giờ (Email)', enabled: true },
                  { label: 'Nhắc lịch trước 1 giờ (SMS)', enabled: true },
                  { label: 'Xác nhận đặt lịch qua Zalo', enabled: false },
                  { label: 'Thông báo khi bác sĩ thay đổi lịch', enabled: true },
                ].map(n => (
                  <div key={n.label} className="flex items-center justify-between py-3 border-b last:border-0"
                    style={{ borderColor: 'var(--color-border)' }}>
                    <span className="text-sm" style={{ color: 'var(--color-ink-2)' }}>{n.label}</span>
                    <div className={`w-11 h-6 rounded-full relative cursor-pointer transition-all`}
                      style={{ background: n.enabled ? 'var(--color-primary)' : 'var(--color-border)' }}>
                      <div className="absolute top-1 w-4 h-4 rounded-full bg-white transition-all"
                        style={{ left: n.enabled ? '26px' : '4px' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
