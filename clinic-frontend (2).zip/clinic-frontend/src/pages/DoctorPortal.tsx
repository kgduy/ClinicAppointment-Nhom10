import React from 'react';
// ... các dòng code tiếp theo
import { useState } from 'react';
import { appointments, patients, formatCurrency, formatDate, statusLabel, statusClass } from '../data/mockData';
import type { AppointmentStatus } from '../data/mockData';

type DoctorView = 'dashboard' | 'appointments' | 'schedule' | 'patients' | 'profile';

interface DoctorPortalProps {
  loggedIn: boolean;
  onLogin: () => void;
}

const WORK_SCHEDULE = [
  { day: 'Thứ 2', slots: ['08:00–11:30', '13:30–17:00'], on: true },
  { day: 'Thứ 3', slots: [], on: false },
  { day: 'Thứ 4', slots: ['08:00–11:30'], on: true },
  { day: 'Thứ 5', slots: ['08:00–11:30', '13:30–17:00'], on: true },
  { day: 'Thứ 6', slots: ['13:30–17:00'], on: true },
  { day: 'Thứ 7', slots: ['08:00–11:30'], on: true },
  { day: 'CN', slots: [], on: false },
];

export default function DoctorPortal({ loggedIn, onLogin }: DoctorPortalProps) {
  const [view, setView] = useState<DoctorView>('dashboard');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [selectedAppt, setSelectedAppt] = useState<string | null>(null);
  const [noteText, setNoteText] = useState('');

  const myAppts = appointments.filter(a => a.doctorId === 'd1');
  const todayAppts = myAppts.filter(a => a.date === '2026-09-19');
  const upcomingAppts = myAppts.filter(a => a.date > '2026-09-19');

  if (!loggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4" style={{ background: 'var(--color-surface-2)' }}>
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl mx-auto mb-4"
              style={{ background: 'var(--color-primary-50)', color: 'var(--color-primary)' }}>
              👨‍⚕️
            </div>
            <h1 className="font-display text-2xl font-semibold mb-1">Cổng bác sĩ</h1>
            <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>Quản lý lịch khám và bệnh nhân</p>
          </div>
          <form onSubmit={e => { e.preventDefault(); onLogin(); }}
            className="bg-white rounded-2xl border p-8 space-y-4"
            style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-elevated)' }}>
            {[
              { label: 'Email', val: loginEmail, set: setLoginEmail, type: 'email', ph: 'bs.nguyenanan@phongkham.vn' },
              { label: 'Mật khẩu', val: loginPass, set: setLoginPass, type: 'password', ph: '••••••••' },
            ].map(f => (
              <div key={f.label}>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-ink-2)' }}>{f.label}</label>
                <input value={f.val} onChange={e => f.set(e.target.value)} type={f.type} placeholder={f.ph}
                  className="w-full px-4 py-3 rounded-xl border text-sm outline-none"
                  style={{ borderColor: 'var(--color-border)' }} />
              </div>
            ))}
            <button type="submit" className="w-full py-3 rounded-xl text-white font-semibold text-sm"
              style={{ background: 'var(--color-primary)' }}>
              Đăng nhập
            </button>
            <button type="button" onClick={onLogin}
              className="w-full py-2.5 rounded-xl border text-sm font-medium"
              style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>
              Demo đăng nhập
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--color-surface-2)' }}>
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-60 min-h-screen bg-white border-r flex-shrink-0"
        style={{ borderColor: 'var(--color-border)' }}>
        <div className="p-4 border-b" style={{ borderColor: 'var(--color-border)' }}>
          <div className="flex items-center gap-3">
            <img src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=80&h=80&fit=crop&auto=format"
              alt="doctor" className="w-10 h-10 rounded-xl object-cover" />
            <div>
              <div className="font-semibold text-sm">TS.BS. Nguyễn Văn An</div>
              <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>Nội tổng quát</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {([
            { key: 'dashboard', icon: '📊', label: 'Tổng quan' },
            { key: 'appointments', icon: '📋', label: 'Lịch hẹn hôm nay' },
            { key: 'schedule', icon: '📅', label: 'Lịch làm việc' },
            { key: 'patients', icon: '👥', label: 'Bệnh nhân' },
            { key: 'profile', icon: '👤', label: 'Hồ sơ cá nhân' },
          ] as const).map(n => (
            <button key={n.key} onClick={() => setView(n.key)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-left transition-all"
              style={{
                background: view === n.key ? 'var(--color-primary-50)' : 'transparent',
                color: view === n.key ? 'var(--color-primary)' : 'var(--color-ink-2)',
              }}>
              <span>{n.icon}</span> {n.label}
              {n.key === 'appointments' && todayAppts.length > 0 && (
                <span className="ml-auto px-2 py-0.5 rounded-full text-xs text-white"
                  style={{ background: 'var(--color-primary)' }}>{todayAppts.length}</span>
              )}
            </button>
          ))}
        </nav>
      </aside>

      {/* Mobile tabs */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t z-40 flex"
        style={{ borderColor: 'var(--color-border)' }}>
        {([
          { key: 'dashboard', icon: '📊', label: 'Tổng quan' },
          { key: 'appointments', icon: '📋', label: 'Lịch hẹn' },
          { key: 'schedule', icon: '📅', label: 'Lịch làm' },
          { key: 'patients', icon: '👥', label: 'BN' },
        ] as const).map(n => (
          <button key={n.key} onClick={() => setView(n.key)}
            className="flex-1 flex flex-col items-center py-2 text-xs"
            style={{ color: view === n.key ? 'var(--color-primary)' : 'var(--color-ink-3)' }}>
            <span className="text-xl">{n.icon}</span>
            {n.label}
          </button>
        ))}
      </div>

      <main className="flex-1 p-4 md:p-8 pb-20 md:pb-8 overflow-auto">
        {/* Dashboard */}
        {view === 'dashboard' && (
          <div className="animate-fade-in max-w-5xl">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="font-display text-2xl font-semibold">Xin chào, BS. An 👋</h1>
                <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>Thứ Sáu, 19 tháng 9 năm 2026 — Cơ sở Quận 1</p>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {[
                { label: 'Hôm nay', value: todayAppts.length.toString(), sub: 'lịch hẹn', icon: '📅', color: 'var(--color-primary)' },
                { label: 'Đang chờ', value: todayAppts.filter(a => a.status === 'pending' || a.status === 'confirmed').length.toString(), sub: 'bệnh nhân', icon: '⏳', color: 'var(--color-warning)' },
                { label: 'Hoàn tất', value: myAppts.filter(a => a.status === 'done').length.toString(), sub: 'ca khám', icon: '✅', color: 'var(--color-success)' },
                { label: 'Doanh thu', value: '1.8M', sub: 'tháng này', icon: '💰', color: 'var(--color-accent)' },
              ].map(s => (
                <div key={s.label} className="bg-white rounded-2xl border p-5"
                  style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-2xl">{s.icon}</span>
                    <span className="font-display text-2xl font-bold" style={{ color: s.color }}>{s.value}</span>
                  </div>
                  <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>{s.sub}</div>
                  <div className="text-sm font-medium mt-0.5" style={{ color: 'var(--color-ink-2)' }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Today's schedule */}
            <div className="bg-white rounded-2xl border p-6"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold">Lịch hẹn hôm nay</h2>
                <button className="text-sm" style={{ color: 'var(--color-primary)' }} onClick={() => setView('appointments')}>
                  Xem tất cả →
                </button>
              </div>
              <div className="space-y-3">
                {todayAppts.map(a => (
                  <div key={a.id} className="flex items-center gap-4 p-3 rounded-xl transition-all hover:bg-gray-50 cursor-pointer"
                    onClick={() => { setSelectedAppt(a.id); setView('appointments'); }}>
                    <div className="text-center w-16 flex-shrink-0">
                      <div className="font-semibold font-mono text-sm" style={{ color: 'var(--color-primary)', fontFamily: 'var(--font-mono)' }}>
                        {a.time}
                      </div>
                    </div>
                    <img src={patients.find(p => p.id === a.patientId)?.avatar} alt={a.patientName}
                      className="w-9 h-9 rounded-lg object-cover flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm" style={{ color: 'var(--color-ink)' }}>{a.patientName}</div>
                      <div className="text-xs" style={{ color: 'var(--color-ink-3)' }}>{a.reason}</div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      {a.type === 'online' && (
                        <span className="text-xs px-2 py-0.5 rounded" style={{ background: '#DBEAFE', color: '#1E40AF' }}>Online</span>
                      )}
                      <span className={`px-2.5 py-1 rounded-lg text-xs font-medium ${statusClass[a.status]}`}>
                        {statusLabel[a.status]}
                      </span>
                    </div>
                  </div>
                ))}
                {todayAppts.length === 0 && (
                  <div className="text-center py-8" style={{ color: 'var(--color-ink-3)' }}>
                    <div className="text-3xl mb-2">📭</div>
                    <p className="text-sm">Không có lịch hẹn hôm nay</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Appointments */}
        {view === 'appointments' && (
          <div className="animate-fade-in max-w-5xl">
            <h1 className="font-display text-2xl font-semibold mb-6">Quản lý lịch hẹn</h1>
            <div className="grid lg:grid-cols-5 gap-5">
              <div className="lg:col-span-3 space-y-4">
                {myAppts.map(a => {
                  const isSelected = selectedAppt === a.id;
                  return (
                    <div key={a.id} onClick={() => setSelectedAppt(isSelected ? null : a.id)}
                      className="bg-white rounded-2xl border p-5 cursor-pointer transition-all"
                      style={{
                        borderColor: isSelected ? 'var(--color-primary)' : 'var(--color-border)',
                        boxShadow: isSelected ? '0 0 0 2px rgba(13,115,119,0.15)' : 'var(--shadow-card)',
                      }}>
                      <div className="flex items-start gap-3">
                        <img src={patients.find(p => p.id === a.patientId)?.avatar} alt={a.patientName}
                          className="w-11 h-11 rounded-xl object-cover flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <div className="font-semibold text-sm">{a.patientName}</div>
                              <div className="text-xs" style={{ color: 'var(--color-ink-3)' }}>
                                {a.date} · {a.time} · {a.type === 'online' ? '💻 Online' : '🏥 Trực tiếp'}
                              </div>
                            </div>
                            <span className={`px-2.5 py-1 rounded-lg text-xs font-medium flex-shrink-0 ${statusClass[a.status]}`}>
                              {statusLabel[a.status]}
                            </span>
                          </div>
                          <div className="mt-2 text-sm" style={{ color: 'var(--color-ink-2)' }}>{a.reason}</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Detail panel */}
              <div className="lg:col-span-2">
                {selectedAppt ? (() => {
                  const a = myAppts.find(x => x.id === selectedAppt)!;
                  const patient = patients.find(p => p.id === a.patientId)!;
                  return (
                    <div className="bg-white rounded-2xl border sticky top-24 p-6"
                      style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-elevated)' }}>
                      <h3 className="font-semibold mb-4">Chi tiết lịch hẹn</h3>
                      <div className="flex items-center gap-3 mb-5 p-3 rounded-xl"
                        style={{ background: 'var(--color-surface-2)' }}>
                        <img src={patient.avatar} alt={patient.name} className="w-12 h-12 rounded-xl object-cover" />
                        <div>
                          <div className="font-semibold text-sm">{patient.name}</div>
                          <div className="text-xs" style={{ color: 'var(--color-ink-3)' }}>
                            {patient.gender === 'male' ? 'Nam' : 'Nữ'} · {new Date().getFullYear() - new Date(patient.dob).getFullYear()} tuổi · {patient.bloodType}
                          </div>
                          <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>{patient.phone}</div>
                        </div>
                      </div>

                      <div className="space-y-2 mb-5 text-sm">
                        {[
                          { k: 'Dịch vụ', v: a.service },
                          { k: 'Ngày', v: formatDate(a.date) },
                          { k: 'Giờ', v: a.time },
                          { k: 'Hình thức', v: a.type === 'online' ? '💻 Online' : '🏥 Trực tiếp' },
                          { k: 'Lý do', v: a.reason },
                        ].map(r => (
                          <div key={r.k} className="flex gap-2">
                            <span className="w-24 flex-shrink-0" style={{ color: 'var(--color-ink-4)' }}>{r.k}</span>
                            <span style={{ color: 'var(--color-ink-2)' }}>{r.v}</span>
                          </div>
                        ))}
                        {a.symptoms && (
                          <div className="flex gap-2">
                            <span className="w-24 flex-shrink-0" style={{ color: 'var(--color-ink-4)' }}>Triệu chứng</span>
                            <span style={{ color: 'var(--color-ink-2)' }}>{a.symptoms}</span>
                          </div>
                        )}
                      </div>

                      {/* Action buttons based on status */}
                      {a.status === 'pending' && (
                        <div className="flex gap-2 mb-4">
                          <button className="flex-1 py-2.5 rounded-xl text-xs font-semibold text-white"
                            style={{ background: 'var(--color-success)' }}>✓ Xác nhận</button>
                          <button className="flex-1 py-2.5 rounded-xl text-xs font-semibold border"
                            style={{ borderColor: 'var(--color-danger)', color: 'var(--color-danger)' }}>✗ Từ chối</button>
                        </div>
                      )}
                      {a.status === 'confirmed' && (
                        <button className="w-full py-2.5 rounded-xl text-xs font-semibold text-white mb-4"
                          style={{ background: 'var(--color-info)' }}>▶ Bắt đầu khám</button>
                      )}
                      {a.status === 'examining' && (
                        <button className="w-full py-2.5 rounded-xl text-xs font-semibold text-white mb-4"
                          style={{ background: 'var(--color-success)' }}>✅ Hoàn tất khám</button>
                      )}

                      {/* Notes */}
                      <div>
                        <label className="block text-xs font-medium mb-1.5" style={{ color: 'var(--color-ink-3)' }}>
                          Ghi chú sau khám / đơn thuốc
                        </label>
                        <textarea value={a.notes || noteText} onChange={e => setNoteText(e.target.value)} rows={4}
                          className="w-full px-3 py-2.5 rounded-xl border text-sm outline-none resize-none"
                          style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-2)' }}
                          placeholder="Kết quả thăm khám, đơn thuốc, lời khuyên..." />
                        <button className="mt-2 px-4 py-2 rounded-lg text-xs font-medium text-white"
                          style={{ background: 'var(--color-primary)' }}>Lưu ghi chú</button>
                      </div>
                    </div>
                  );
                })() : (
                  <div className="bg-white rounded-2xl border p-8 text-center"
                    style={{ borderColor: 'var(--color-border)' }}>
                    <div className="text-3xl mb-3">👈</div>
                    <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>Chọn lịch hẹn để xem chi tiết</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Schedule */}
        {view === 'schedule' && (
          <div className="animate-fade-in max-w-4xl">
            <div className="flex items-center justify-between mb-6">
              <h1 className="font-display text-2xl font-semibold">Lịch làm việc</h1>
              <button className="px-4 py-2 rounded-xl text-sm font-semibold text-white"
                style={{ background: 'var(--color-primary)' }}>+ Thêm ca làm</button>
            </div>

            <div className="bg-white rounded-2xl border p-6 mb-6"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <h2 className="font-semibold mb-4">Lịch tuần này (T3/09 – T9/09/2026)</h2>
              <div className="grid grid-cols-7 gap-2">
                {WORK_SCHEDULE.map((d, i) => (
                  <div key={i} className={`rounded-xl p-3 min-h-[120px] transition-all`}
                    style={{ background: d.on ? 'var(--color-primary-50)' : 'var(--color-surface-2)' }}>
                    <div className="text-xs font-medium mb-2"
                      style={{ color: d.on ? 'var(--color-primary)' : 'var(--color-ink-4)' }}>{d.day}</div>
                    {d.on ? d.slots.map((s, j) => (
                      <div key={j} className="text-xs rounded px-1.5 py-1 mb-1 font-mono"
                        style={{ background: 'white', color: 'var(--color-primary)', fontFamily: 'var(--font-mono)', fontSize: '10px' }}>
                        {s}
                      </div>
                    )) : (
                      <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>Nghỉ</div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl border p-6"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <h2 className="font-semibold mb-4">Chỉnh sửa lịch làm việc</h2>
              <div className="space-y-4">
                {WORK_SCHEDULE.map((d, i) => (
                  <div key={i} className="flex items-center gap-4 p-3 rounded-xl border"
                    style={{ borderColor: 'var(--color-border)' }}>
                    <div className="w-10 text-sm font-medium" style={{ color: 'var(--color-ink-2)' }}>{d.day}</div>
                    <div className={`w-11 h-6 rounded-full relative cursor-pointer`}
                      style={{ background: d.on ? 'var(--color-primary)' : 'var(--color-border)' }}>
                      <div className="absolute top-1 w-4 h-4 rounded-full bg-white transition-all"
                        style={{ left: d.on ? '26px' : '4px' }} />
                    </div>
                    {d.on && (
                      <div className="flex flex-wrap gap-2">
                        {d.slots.map((s, j) => (
                          <span key={j} className="px-3 py-1 rounded-lg text-xs border font-mono"
                            style={{ borderColor: 'var(--color-border)', color: 'var(--color-primary)', fontFamily: 'var(--font-mono)' }}>
                            {s}
                          </span>
                        ))}
                        <button className="px-3 py-1 rounded-lg text-xs border border-dashed"
                          style={{ borderColor: 'var(--color-primary)', color: 'var(--color-primary)' }}>
                          + Ca
                        </button>
                      </div>
                    )}
                    {!d.on && <span className="text-sm" style={{ color: 'var(--color-ink-4)' }}>Ngày nghỉ</span>}
                  </div>
                ))}
              </div>
              <div className="mt-5 flex gap-3">
                <button className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white"
                  style={{ background: 'var(--color-primary)' }}>Lưu lịch làm việc</button>
                <button className="px-5 py-2.5 rounded-xl text-sm border font-medium"
                  style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>Đăng ký ngày nghỉ phép</button>
              </div>
            </div>
          </div>
        )}

        {/* Patients */}
        {view === 'patients' && (
          <div className="animate-fade-in max-w-4xl">
            <h1 className="font-display text-2xl font-semibold mb-6">Danh sách bệnh nhân</h1>
            <div className="bg-white rounded-2xl border overflow-hidden"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <div className="p-4 border-b" style={{ borderColor: 'var(--color-border)' }}>
                <input className="w-full max-w-sm px-4 py-2.5 rounded-xl border text-sm outline-none"
                  style={{ borderColor: 'var(--color-border)' }} placeholder="🔍 Tìm bệnh nhân..." />
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ background: 'var(--color-surface-2)' }}>
                      {['Bệnh nhân', 'Ngày sinh', 'SĐT', 'Nhóm máu', 'Lần khám', 'Lần cuối'].map(h => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-semibold"
                          style={{ color: 'var(--color-ink-3)', fontFamily: 'var(--font-mono)' }}>
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {patients.map((p, i) => (
                      <tr key={p.id} className="border-t hover:bg-gray-50 transition-colors"
                        style={{ borderColor: 'var(--color-border)' }}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <img src={p.avatar} alt={p.name} className="w-8 h-8 rounded-lg object-cover" />
                            <div>
                              <div className="font-medium text-sm" style={{ color: 'var(--color-ink)' }}>{p.name}</div>
                              <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>{p.gender === 'male' ? 'Nam' : 'Nữ'}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-ink-2)' }}>
                          {new Date(p.dob).toLocaleDateString('vi-VN')}
                        </td>
                        <td className="px-4 py-3 text-sm font-mono" style={{ color: 'var(--color-ink-2)', fontFamily: 'var(--font-mono)' }}>
                          {p.phone}
                        </td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-0.5 rounded text-xs font-mono"
                            style={{ background: 'var(--color-primary-50)', color: 'var(--color-primary)', fontFamily: 'var(--font-mono)' }}>
                            {p.bloodType}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-ink-2)' }}>
                          {p.appointmentCount} lần
                        </td>
                        <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-ink-3)' }}>
                          {new Date(p.lastVisit).toLocaleDateString('vi-VN')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Profile */}
        {view === 'profile' && (
          <div className="animate-fade-in max-w-2xl">
            <h1 className="font-display text-2xl font-semibold mb-6">Hồ sơ bác sĩ</h1>
            <div className="bg-white rounded-2xl border p-6 mb-6"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <div className="flex items-start gap-5 mb-6">
                <img src="https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=120&h=120&fit=crop&auto=format"
                  alt="doctor" className="w-24 h-24 rounded-2xl object-cover" />
                <div>
                  <h2 className="font-display text-xl font-semibold">TS.BS. Nguyễn Văn An</h2>
                  <p className="text-sm mb-1" style={{ color: 'var(--color-ink-3)' }}>Nội tổng quát · 18 năm kinh nghiệm</p>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2.5 py-1 rounded-full"
                      style={{ background: 'var(--color-primary-50)', color: 'var(--color-primary)' }}>
                      ⭐ 4.9/5 (312 đánh giá)
                    </span>
                  </div>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                {[
                  { label: 'Học hàm / Học vị', value: 'Tiến sĩ – BSCK II' },
                  { label: 'Chuyên khoa', value: 'Nội tổng quát' },
                  { label: 'Cơ sở', value: 'Cơ sở Quận 1' },
                  { label: 'Email', value: 'bs.nguyenanan@phongkham.vn' },
                  { label: 'Điện thoại', value: '028 3822 1234' },
                  { label: 'Ngôn ngữ', value: 'Tiếng Việt, English' },
                ].map(f => (
                  <div key={f.label}>
                    <label className="block text-xs mb-1" style={{ color: 'var(--color-ink-4)', fontFamily: 'var(--font-mono)' }}>{f.label}</label>
                    <input defaultValue={f.value} className="w-full px-3 py-2.5 rounded-lg border text-sm outline-none"
                      style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-2)' }} />
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <label className="block text-xs mb-1" style={{ color: 'var(--color-ink-4)', fontFamily: 'var(--font-mono)' }}>Tiểu sử</label>
                <textarea rows={3} defaultValue="Hơn 18 năm kinh nghiệm trong lĩnh vực nội khoa tổng quát, chuyên sâu về bệnh tiểu đường, huyết áp và các bệnh mãn tính."
                  className="w-full px-3 py-2.5 rounded-lg border text-sm outline-none resize-none"
                  style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-2)' }} />
              </div>
              <button className="mt-4 px-5 py-2.5 rounded-xl text-sm font-semibold text-white"
                style={{ background: 'var(--color-primary)' }}>Lưu thay đổi</button>
            </div>

            <div className="bg-white rounded-2xl border p-6" style={{ borderColor: 'var(--color-border)' }}>
              <h3 className="font-semibold mb-4">Giá khám</h3>
              <div className="flex items-center justify-between p-3 rounded-xl"
                style={{ background: 'var(--color-surface-2)' }}>
                <span className="text-sm" style={{ color: 'var(--color-ink-2)' }}>Phí khám cơ bản</span>
                <span className="font-semibold" style={{ color: 'var(--color-primary)' }}>{formatCurrency(300000)}</span>
              </div>
              <p className="text-xs mt-2" style={{ color: 'var(--color-ink-4)' }}>
                Liên hệ quản trị để thay đổi giá khám
              </p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
