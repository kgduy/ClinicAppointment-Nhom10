import React from 'react';
// ... các dòng code tiếp theo
import { useState } from 'react';
import { doctors, specialties, formatCurrency, branches } from '../data/mockData';
import { Role } from '../data/mockData';

interface LandingProps {
  setActivePortal: (p: Role | 'landing') => void;
}

export default function Landing({ setActivePortal }: LandingProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('');

  const filtered = doctors.filter(d => {
    const q = searchQuery.toLowerCase();
    const matchQ = !q || d.name.toLowerCase().includes(q) || d.specialty.toLowerCase().includes(q);
    const matchSp = !selectedSpecialty || d.specialtyId === selectedSpecialty;
    return matchQ && matchSp;
  });

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden" style={{ background: 'linear-gradient(135deg, var(--color-primary-dark) 0%, var(--color-primary) 50%, var(--color-primary-light) 100%)' }}>
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full" style={{ background: 'white', transform: 'translate(30%, -30%)' }} />
          <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full" style={{ background: 'white', transform: 'translate(-30%, 30%)' }} />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 py-16 md:py-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium mb-6"
                style={{ background: 'rgba(255,255,255,0.15)', color: 'white', fontFamily: 'var(--font-mono)' }}>
                ✦ Đặt lịch trực tuyến 24/7
              </div>
              <h1 className="font-display text-4xl md:text-5xl font-semibold text-white leading-tight mb-4">
                Chăm sóc sức khỏe<br />
                <em className="not-italic" style={{ color: 'var(--color-accent-light)' }}>tận tâm</em>{' '}
                & chuyên nghiệp
              </h1>
              <p className="text-lg mb-8 leading-relaxed" style={{ color: 'rgba(255,255,255,0.82)' }}>
                Đặt lịch khám với đội ngũ bác sĩ chuyên khoa hàng đầu. Nhanh chóng, thuận tiện, an toàn thông tin y tế.
              </p>
              <div className="flex flex-wrap gap-3">
                <button onClick={() => setActivePortal('patient')}
                  className="px-6 py-3 rounded-xl font-semibold text-sm transition-all hover:scale-105"
                  style={{ background: 'white', color: 'var(--color-primary-dark)' }}>
                  Đặt lịch ngay
                </button>
                <button onClick={() => setActivePortal('patient')}
                  className="px-6 py-3 rounded-xl font-medium text-sm border transition-all hover:bg-white hover:bg-opacity-10"
                  style={{ borderColor: 'rgba(255,255,255,0.4)', color: 'white' }}>
                  Xem bác sĩ
                </button>
              </div>
            </div>
            <div className="hidden md:flex justify-center">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1631217868264-e5b90bb7e133?w=420&h=380&fit=crop&auto=format"
                  alt="Bác sĩ tại phòng khám"
                  className="rounded-2xl shadow-2xl"
                  style={{ width: 380, height: 320, objectFit: 'cover' }}
                />
                {/* Stat card */}
                <div className="absolute -bottom-4 -left-6 bg-white rounded-xl p-4 shadow-xl" style={{ minWidth: 160 }}>
                  <div className="text-2xl font-display font-bold" style={{ color: 'var(--color-primary)' }}>15,000+</div>
                  <div className="text-sm mt-0.5" style={{ color: 'var(--color-ink-3)' }}>Bệnh nhân tin tưởng</div>
                </div>
                <div className="absolute -top-4 -right-4 bg-white rounded-xl p-4 shadow-xl">
                  <div className="text-2xl font-display font-bold" style={{ color: 'var(--color-accent)' }}>⭐ 4.9</div>
                  <div className="text-sm mt-0.5" style={{ color: 'var(--color-ink-3)' }}>Đánh giá trung bình</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="border-b" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-2)' }}>
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { value: '27+', label: 'Bác sĩ chuyên khoa', icon: '👨‍⚕️' },
              { value: '8', label: 'Chuyên khoa', icon: '🏥' },
              { value: '3', label: 'Cơ sở khám', icon: '📍' },
              { value: '98%', label: 'Tỷ lệ hài lòng', icon: '💚' },
            ].map(s => (
              <div key={s.label} className="flex items-center gap-3">
                <span className="text-2xl">{s.icon}</span>
                <div>
                  <div className="font-display font-bold text-xl" style={{ color: 'var(--color-primary)' }}>{s.value}</div>
                  <div className="text-sm" style={{ color: 'var(--color-ink-3)' }}>{s.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Search + Specialty filter */}
      <section className="py-12 max-w-7xl mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="font-display text-3xl font-semibold mb-2" style={{ color: 'var(--color-ink)' }}>
            Tìm bác sĩ phù hợp
          </h2>
          <p style={{ color: 'var(--color-ink-3)' }}>Lọc theo chuyên khoa, tên bác sĩ hoặc triệu chứng</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 mb-8">
          <div className="relative flex-1">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg">🔍</span>
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Tên bác sĩ, chuyên khoa, triệu chứng..."
              className="w-full pl-11 pr-4 py-3 rounded-xl border text-sm outline-none transition-all"
              style={{ borderColor: 'var(--color-border)', background: 'white' }}
              onFocus={e => e.currentTarget.style.borderColor = 'var(--color-primary)'}
              onBlur={e => e.currentTarget.style.borderColor = 'var(--color-border)'}
            />
          </div>
          <select
            value={selectedSpecialty}
            onChange={e => setSelectedSpecialty(e.target.value)}
            className="px-4 py-3 rounded-xl border text-sm outline-none"
            style={{ borderColor: 'var(--color-border)', background: 'white', minWidth: 200, color: 'var(--color-ink-2)' }}
          >
            <option value="">Tất cả chuyên khoa</option>
            {specialties.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </div>

        {/* Specialty pills */}
        <div className="flex flex-wrap gap-2 mb-8">
          {specialties.map(s => (
            <button
              key={s.id}
              onClick={() => setSelectedSpecialty(selectedSpecialty === s.id ? '' : s.id)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium border transition-all"
              style={{
                borderColor: selectedSpecialty === s.id ? s.color : 'var(--color-border)',
                background: selectedSpecialty === s.id ? s.color : 'white',
                color: selectedSpecialty === s.id ? 'white' : 'var(--color-ink-2)',
              }}
            >
              <span>{s.icon}</span>
              {s.name}
            </button>
          ))}
        </div>

        {/* Doctors grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map(doc => (
            <div key={doc.id} className="rounded-2xl border overflow-hidden transition-all hover:-translate-y-1 cursor-pointer"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}
              onClick={() => setActivePortal('patient')}>
              <div className="p-5">
                <div className="flex items-start gap-4">
                  <img src={doc.photo} alt={doc.name}
                    className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                    style={{ background: 'var(--color-surface-3)' }} />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`inline-block w-2 h-2 rounded-full flex-shrink-0 ${doc.available ? '' : 'opacity-40'}`}
                        style={{ background: doc.available ? 'var(--color-success)' : '#9CA3AF' }} />
                      <span className="text-xs" style={{ color: doc.available ? 'var(--color-success)' : 'var(--color-ink-4)' }}>
                        {doc.available ? 'Đang nhận lịch' : 'Tạm nghỉ'}
                      </span>
                    </div>
                    <h3 className="font-semibold text-sm leading-snug" style={{ color: 'var(--color-ink)' }}>{doc.name}</h3>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--color-ink-3)' }}>{doc.title}</p>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium"
                    style={{ background: 'var(--color-primary-50)', color: 'var(--color-primary)' }}>
                    {specialties.find(s => s.id === doc.specialtyId)?.icon} {doc.specialty}
                  </span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs"
                    style={{ background: 'var(--color-surface-2)', color: 'var(--color-ink-3)' }}>
                    📍 {doc.branch}
                  </span>
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs" style={{ color: 'var(--color-ink-3)' }}>
                    <span>⭐ {doc.rating} ({doc.reviewCount})</span>
                    <span>🏆 {doc.experience} năm</span>
                  </div>
                  <span className="font-semibold text-sm" style={{ color: 'var(--color-primary)' }}>
                    {formatCurrency(doc.price)}
                  </span>
                </div>
              </div>
              <div className="px-5 pb-4">
                <button
                  className="w-full py-2.5 rounded-xl text-sm font-semibold transition-all"
                  style={{
                    background: doc.available ? 'var(--color-primary)' : 'var(--color-surface-3)',
                    color: doc.available ? 'white' : 'var(--color-ink-4)',
                  }}
                >
                  {doc.available ? 'Đặt lịch khám' : 'Chưa có lịch'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16" style={{ color: 'var(--color-ink-3)' }}>
            <div className="text-4xl mb-3">🔍</div>
            <p>Không tìm thấy bác sĩ phù hợp</p>
          </div>
        )}
      </section>

      {/* How it works */}
      <section className="py-16" style={{ background: 'var(--color-surface-2)' }}>
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="font-display text-3xl font-semibold mb-2">Đặt lịch chỉ 4 bước</h2>
            <p style={{ color: 'var(--color-ink-3)' }}>Nhanh chóng, đơn giản — hoàn tất trong 2 phút</p>
          </div>
          <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { step: '01', icon: '🔍', title: 'Chọn bác sĩ', desc: 'Tìm bác sĩ theo chuyên khoa hoặc triệu chứng' },
              { step: '02', icon: '📅', title: 'Chọn ngày giờ', desc: 'Xem slot trống theo thời gian thực' },
              { step: '03', icon: '📝', title: 'Nhập thông tin', desc: 'Lý do khám và triệu chứng ban đầu' },
              { step: '04', icon: '✅', title: 'Xác nhận', desc: 'Nhận xác nhận qua email / SMS' },
            ].map((s, i) => (
              <div key={i} className="relative">
                {i < 3 && (
                  <div className="hidden md:block absolute top-8 left-full w-full h-px -translate-x-1/2"
                    style={{ background: 'var(--color-border-strong)' }} />
                )}
                <div className="bg-white rounded-2xl p-6 border" style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                  <div className="font-mono text-xs font-medium mb-3" style={{ color: 'var(--color-primary)', fontFamily: 'var(--font-mono)' }}>
                    {s.step}
                  </div>
                  <div className="text-3xl mb-3">{s.icon}</div>
                  <h3 className="font-semibold mb-1" style={{ color: 'var(--color-ink)' }}>{s.title}</h3>
                  <p className="text-sm leading-relaxed" style={{ color: 'var(--color-ink-3)' }}>{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Branches */}
      <section className="py-16 max-w-7xl mx-auto px-4">
        <h2 className="font-display text-3xl font-semibold mb-8">Hệ thống cơ sở</h2>
        <div className="grid md:grid-cols-3 gap-5">
          {branches.map(b => (
            <div key={b.id} className="rounded-2xl border overflow-hidden" style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <div className="h-40 relative overflow-hidden">
                <img
                  src={`https://images.unsplash.com/photo-${b.id === 'b1' ? '1519494026892-80bbd2d6fd0d' : b.id === 'b2' ? '1586773860418-d37222d8fce3' : '1504439468489-c8920d796a29'}?w=600&h=240&fit=crop&auto=format`}
                  alt={b.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.5), transparent)' }} />
                <div className="absolute bottom-3 left-4 text-white font-semibold">{b.name}</div>
              </div>
              <div className="p-5 space-y-2 text-sm" style={{ color: 'var(--color-ink-2)' }}>
                <div className="flex items-start gap-2">
                  <span className="mt-0.5 flex-shrink-0">📍</span>
                  <span>{b.address}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span>📞</span>
                  <span>{b.phone}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="mt-0.5 flex-shrink-0">🕐</span>
                  <span style={{ color: 'var(--color-ink-3)' }}>{b.hours}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-16" style={{ background: 'var(--color-primary-dark)' }}>
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="font-display text-3xl font-semibold text-white mb-4">
            Sẵn sàng đặt lịch?
          </h2>
          <p className="mb-8 text-lg" style={{ color: 'rgba(255,255,255,0.75)' }}>
            Đăng ký tài khoản miễn phí và đặt lịch ngay hôm nay
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <button onClick={() => setActivePortal('patient')}
              className="px-8 py-3.5 rounded-xl font-semibold transition-all hover:scale-105"
              style={{ background: 'white', color: 'var(--color-primary-dark)' }}>
              Đăng ký bệnh nhân
            </button>
            <button onClick={() => setActivePortal('doctor')}
              className="px-8 py-3.5 rounded-xl font-medium border transition-all"
              style={{ borderColor: 'rgba(255,255,255,0.4)', color: 'white' }}>
              Dành cho bác sĩ
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8" style={{ borderColor: 'var(--color-border)', background: 'var(--color-surface-2)' }}>
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-sm" style={{ color: 'var(--color-ink-3)' }}>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold"
              style={{ background: 'var(--color-primary)' }}>P</div>
            <span className="font-medium" style={{ color: 'var(--color-ink-2)' }}>PhòngKhám+</span>
          </div>
          <div>© 2026 PhòngKhám+. Mọi quyền được bảo lưu.</div>
          <div className="flex gap-4">
            <a href="#" className="hover:underline">Điều khoản</a>
            <a href="#" className="hover:underline">Bảo mật</a>
            <a href="#" className="hover:underline">Liên hệ</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
