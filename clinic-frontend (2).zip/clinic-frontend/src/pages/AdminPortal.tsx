import React from 'react';
// ... các dòng code tiếp theo
import { useState } from 'react';
import { appointments, patients, doctors, services, formatCurrency, statusLabel, statusClass, auditLog, branches, specialties } from '../data/mockData';
import type { AppointmentStatus } from '../data/mockData';

type AdminView = 'dashboard' | 'appointments' | 'patients' | 'doctors' | 'specialties' | 'services' | 'schedule' | 'reports' | 'audit' | 'queue';

interface AdminPortalProps {
  loggedIn: boolean;
  onLogin: () => void;
}

export default function AdminPortal({ loggedIn, onLogin }: AdminPortalProps) {
  const [view, setView] = useState<AdminView>('dashboard');
  const [statusFilter, setStatusFilter] = useState<AppointmentStatus | 'all'>('all');

  const filteredAppts = statusFilter === 'all' ? appointments : appointments.filter(a => a.status === statusFilter);

  if (!loggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4" style={{ background: 'var(--color-surface-2)' }}>
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl mx-auto mb-4"
              style={{ background: '#0F1923', color: 'white' }}>🔐</div>
            <h1 className="font-display text-2xl font-semibold mb-1">Quản trị hệ thống</h1>
            <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>Admin · Lễ tân · Quản lý cơ sở</p>
          </div>
          <form onSubmit={e => { e.preventDefault(); onLogin(); }}
            className="bg-white rounded-2xl border p-8 space-y-4"
            style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-elevated)' }}>
            {[
              { label: 'Email', type: 'email', ph: 'admin@phongkham.vn' },
              { label: 'Mật khẩu', type: 'password', ph: '••••••••' },
            ].map(f => (
              <div key={f.label}>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-ink-2)' }}>{f.label}</label>
                <input type={f.type} placeholder={f.ph}
                  className="w-full px-4 py-3 rounded-xl border text-sm outline-none"
                  style={{ borderColor: 'var(--color-border)' }} />
              </div>
            ))}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-ink-2)' }}>Vai trò</label>
              <select className="w-full px-4 py-3 rounded-xl border text-sm outline-none"
                style={{ borderColor: 'var(--color-border)' }}>
                <option>Admin</option>
                <option>Lễ tân</option>
                <option>Quản lý cơ sở</option>
              </select>
            </div>
            <button type="submit" className="w-full py-3 rounded-xl font-semibold text-sm text-white"
              style={{ background: '#0F1923' }}>Đăng nhập quản trị</button>
            <button type="button" onClick={onLogin}
              className="w-full py-2.5 rounded-xl border text-sm font-medium"
              style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>Demo đăng nhập</button>
          </form>
        </div>
      </div>
    );
  }

  const navItems: { key: AdminView; icon: string; label: string; group?: string }[] = [
    { key: 'dashboard', icon: '📊', label: 'Dashboard', group: 'Tổng quan' },
    { key: 'queue', icon: '🔢', label: 'Hàng đợi hôm nay', group: 'Tổng quan' },
    { key: 'appointments', icon: '📋', label: 'Lịch hẹn', group: 'Quản lý' },
    { key: 'patients', icon: '🧑‍🤝‍🧑', label: 'Bệnh nhân', group: 'Quản lý' },
    { key: 'doctors', icon: '👨‍⚕️', label: 'Bác sĩ', group: 'Quản lý' },
    { key: 'specialties', icon: '🏥', label: 'Chuyên khoa', group: 'Danh mục' },
    { key: 'services', icon: '💊', label: 'Dịch vụ & Giá', group: 'Danh mục' },
    { key: 'schedule', icon: '🗓️', label: 'Lịch làm việc', group: 'Danh mục' },
    { key: 'reports', icon: '📈', label: 'Thống kê', group: 'Báo cáo' },
    { key: 'audit', icon: '📝', label: 'Nhật ký hệ thống', group: 'Báo cáo' },
  ];

  const groups = ['Tổng quan', 'Quản lý', 'Danh mục', 'Báo cáo'];

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--color-surface-2)' }}>
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-60 min-h-screen border-r flex-shrink-0"
        style={{ background: '#0F1923', borderColor: 'rgba(255,255,255,0.06)' }}>
        <div className="p-4 border-b" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm"
              style={{ background: 'var(--color-primary)', color: 'white' }}>A</div>
            <div>
              <div className="text-sm font-semibold text-white">Admin Hà</div>
              <div className="text-xs" style={{ color: 'rgba(255,255,255,0.45)' }}>Quản trị hệ thống</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-3 overflow-auto">
          {groups.map(g => (
            <div key={g} className="mb-4">
              <div className="px-3 mb-1 text-xs font-semibold uppercase tracking-wider"
                style={{ color: 'rgba(255,255,255,0.3)', fontFamily: 'var(--font-mono)' }}>{g}</div>
              {navItems.filter(n => n.group === g).map(n => (
                <button key={n.key} onClick={() => setView(n.key)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-left transition-all mb-0.5"
                  style={{
                    background: view === n.key ? 'rgba(13,115,119,0.25)' : 'transparent',
                    color: view === n.key ? 'var(--color-primary-light)' : 'rgba(255,255,255,0.65)',
                  }}>
                  <span>{n.icon}</span> {n.label}
                </button>
              ))}
            </div>
          ))}
        </nav>
        <div className="p-3 border-t" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
          <div className="px-3 py-2 text-xs" style={{ color: 'rgba(255,255,255,0.3)' }}>
            v2.1.0 · PhòngKhám+
          </div>
        </div>
      </aside>

      {/* Mobile bottom nav */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-gray-900 border-t z-40 flex"
        style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
        {[
          { key: 'dashboard', icon: '📊', label: 'Dashboard' },
          { key: 'appointments', icon: '📋', label: 'Lịch hẹn' },
          { key: 'patients', icon: '👥', label: 'BN' },
          { key: 'reports', icon: '📈', label: 'Thống kê' },
        ].map((n: any) => (
          <button key={n.key} onClick={() => setView(n.key)}
            className="flex-1 flex flex-col items-center py-2 text-xs"
            style={{ color: view === n.key ? 'var(--color-primary-light)' : 'rgba(255,255,255,0.45)' }}>
            <span className="text-xl">{n.icon}</span>{n.label}
          </button>
        ))}
      </div>

      <main className="flex-1 p-4 md:p-8 pb-20 md:pb-8 overflow-auto">
        {/* Dashboard */}
        {view === 'dashboard' && (
          <div className="animate-fade-in max-w-6xl">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="font-display text-2xl font-semibold">Dashboard</h1>
                <p className="text-sm" style={{ color: 'var(--color-ink-3)' }}>Thứ Sáu, 19 tháng 9 năm 2026</p>
              </div>
              <div className="flex gap-2">
                <select className="px-3 py-2 rounded-xl border text-sm outline-none"
                  style={{ borderColor: 'var(--color-border)', background: 'white' }}>
                  <option>Tất cả cơ sở</option>
                  {branches.map(b => <option key={b.id}>{b.name}</option>)}
                </select>
              </div>
            </div>

            {/* KPI cards */}
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
              {[
                { label: 'Tổng lịch hẹn', value: appointments.length, icon: '📅', color: 'var(--color-primary)', bg: 'var(--color-primary-50)' },
                { label: 'Chờ xác nhận', value: appointments.filter(a => a.status === 'pending').length, icon: '⏳', color: '#F59E0B', bg: '#FEF3C7' },
                { label: 'Đang khám', value: appointments.filter(a => a.status === 'examining').length, icon: '🔵', color: '#3B82F6', bg: '#DBEAFE' },
                { label: 'Hoàn tất', value: appointments.filter(a => a.status === 'done').length, icon: '✅', color: 'var(--color-success)', bg: '#D1FAE5' },
                { label: 'Đã hủy', value: appointments.filter(a => a.status === 'cancelled').length, icon: '❌', color: 'var(--color-danger)', bg: '#FEE2E2' },
              ].map(s => (
                <div key={s.label} className="bg-white rounded-2xl border p-5"
                  style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg"
                      style={{ background: s.bg }}>{s.icon}</div>
                    <span className="font-display text-3xl font-bold" style={{ color: s.color }}>{s.value}</span>
                  </div>
                  <div className="text-sm" style={{ color: 'var(--color-ink-3)' }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Revenue & charts placeholder */}
            <div className="grid lg:grid-cols-3 gap-5 mb-6">
              <div className="lg:col-span-2 bg-white rounded-2xl border p-6"
                style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="font-semibold">Lượt khám theo ngày (Tháng 9/2026)</h2>
                  <select className="px-3 py-1.5 rounded-lg border text-xs outline-none"
                    style={{ borderColor: 'var(--color-border)' }}>
                    <option>Tháng 9</option>
                  </select>
                </div>
                {/* Bar chart visualization */}
                <div className="flex items-end gap-1 h-40">
                  {[32, 45, 38, 52, 48, 0, 0, 41, 56, 49, 63, 57, 44, 0, 0, 38, 51, 47, 8].map((v, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-1">
                      <div className="w-full rounded-t transition-all"
                        style={{
                          height: v ? `${(v / 63) * 100}%` : '4%',
                          background: v === 0 ? 'var(--color-surface-3)' : v === 8 ? 'var(--color-primary-100)' : 'var(--color-primary)',
                          minHeight: 4,
                        }} />
                      {(i + 1) % 5 === 1 && (
                        <span className="text-xs" style={{ color: 'var(--color-ink-4)', fontSize: '9px', fontFamily: 'var(--font-mono)' }}>{i + 1}</span>
                      )}
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-4 mt-3 text-xs" style={{ color: 'var(--color-ink-3)' }}>
                  <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded inline-block" style={{ background: 'var(--color-primary)' }}/>Có khám</span>
                  <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded inline-block" style={{ background: 'var(--color-surface-3)' }}/>Nghỉ</span>
                </div>
              </div>

              <div className="bg-white rounded-2xl border p-6"
                style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                <h2 className="font-semibold mb-4">Doanh thu</h2>
                {[
                  { label: 'Hôm nay', value: '18.5M ₫', trend: '+12%' },
                  { label: 'Tuần này', value: '94.2M ₫', trend: '+8%' },
                  { label: 'Tháng này', value: '387.6M ₫', trend: '+15%' },
                ].map(r => (
                  <div key={r.label} className="flex items-center justify-between py-3 border-b last:border-0"
                    style={{ borderColor: 'var(--color-border)' }}>
                    <span className="text-sm" style={{ color: 'var(--color-ink-3)' }}>{r.label}</span>
                    <div className="text-right">
                      <div className="font-semibold text-sm" style={{ color: 'var(--color-ink)' }}>{r.value}</div>
                      <div className="text-xs" style={{ color: 'var(--color-success)' }}>{r.trend}</div>
                    </div>
                  </div>
                ))}
                <div className="mt-4 rounded-xl p-3" style={{ background: 'var(--color-surface-2)' }}>
                  <div className="text-xs mb-1" style={{ color: 'var(--color-ink-3)' }}>Tỷ lệ hủy lịch</div>
                  <div className="font-semibold" style={{ color: 'var(--color-danger)' }}>14.3%</div>
                  <div className="text-xs mt-1" style={{ color: 'var(--color-ink-4)' }}>Mục tiêu: &lt; 10%</div>
                </div>
              </div>
            </div>

            {/* Top doctors + Recent appointments */}
            <div className="grid lg:grid-cols-2 gap-5">
              <div className="bg-white rounded-2xl border p-6"
                style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                <h2 className="font-semibold mb-4">Bác sĩ nhiều lịch nhất</h2>
                <div className="space-y-3">
                  {doctors.slice(0, 4).map((d, i) => (
                    <div key={d.id} className="flex items-center gap-3">
                      <span className="w-6 text-center text-sm font-mono font-semibold"
                        style={{ color: i === 0 ? 'var(--color-accent)' : 'var(--color-ink-4)', fontFamily: 'var(--font-mono)' }}>
                        {i + 1}
                      </span>
                      <img src={d.photo} alt={d.name} className="w-9 h-9 rounded-lg object-cover flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">{d.name}</div>
                        <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>{d.specialty}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-semibold" style={{ color: 'var(--color-primary)' }}>
                          {[12, 9, 8, 7][i]} ca
                        </div>
                        <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>tháng này</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-2xl border p-6"
                style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                <h2 className="font-semibold mb-4">Dịch vụ phổ biến</h2>
                <div className="space-y-3">
                  {[
                    { name: 'Khám nội tổng quát', count: 48, pct: 78 },
                    { name: 'Khám nhi', count: 32, pct: 62 },
                    { name: 'Khám da liễu', count: 28, pct: 55 },
                    { name: 'Siêu âm ổ bụng', count: 24, pct: 48 },
                  ].map(s => (
                    <div key={s.name}>
                      <div className="flex justify-between text-sm mb-1.5">
                        <span style={{ color: 'var(--color-ink-2)' }}>{s.name}</span>
                        <span className="font-mono" style={{ color: 'var(--color-ink-3)', fontFamily: 'var(--font-mono)' }}>
                          {s.count} lượt
                        </span>
                      </div>
                      <div className="h-1.5 rounded-full" style={{ background: 'var(--color-surface-3)' }}>
                        <div className="h-full rounded-full transition-all"
                          style={{ width: `${s.pct}%`, background: 'var(--color-primary)' }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Queue */}
        {view === 'queue' && (
          <div className="animate-fade-in max-w-4xl">
            <h1 className="font-display text-2xl font-semibold mb-6">Hàng đợi hôm nay</h1>
            <div className="grid sm:grid-cols-3 gap-4 mb-6">
              {[
                { label: 'Đang phục vụ', value: '07', icon: '🔵', color: '#3B82F6' },
                { label: 'Đang chờ', value: '08', icon: '⏳', color: 'var(--color-warning)' },
                { label: 'Đã khám', value: '42', icon: '✅', color: 'var(--color-success)' },
              ].map(s => (
                <div key={s.label} className="bg-white rounded-2xl border p-5 text-center"
                  style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                  <div className="text-3xl mb-2">{s.icon}</div>
                  <div className="font-display text-4xl font-bold mb-1" style={{ color: s.color }}>{s.value}</div>
                  <div className="text-sm" style={{ color: 'var(--color-ink-3)' }}>{s.label}</div>
                </div>
              ))}
            </div>
            <div className="bg-white rounded-2xl border p-6"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold">Danh sách chờ</h2>
                <button className="px-4 py-2 rounded-xl text-sm font-semibold text-white"
                  style={{ background: 'var(--color-primary)' }}>▶ Gọi tiếp theo</button>
              </div>
              <div className="space-y-3">
                {appointments.filter(a => ['confirmed', 'examining', 'pending'].includes(a.status)).map((a, i) => (
                  <div key={a.id} className="flex items-center gap-4 p-3 rounded-xl transition-all"
                    style={{
                      background: a.status === 'examining' ? 'var(--color-primary-50)' : i === 1 ? '#FEF9C3' : 'var(--color-surface-2)',
                    }}>
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center font-display font-bold text-lg flex-shrink-0"
                      style={{
                        background: a.status === 'examining' ? 'var(--color-primary)' : 'var(--color-border)',
                        color: a.status === 'examining' ? 'white' : 'var(--color-ink-3)',
                      }}>
                      {String(i + 7).padStart(2, '0')}
                    </div>
                    <img src={patients.find(p => p.id === a.patientId)?.avatar} alt={a.patientName}
                      className="w-9 h-9 rounded-lg object-cover flex-shrink-0" />
                    <div className="flex-1">
                      <div className="font-medium text-sm">{a.patientName}</div>
                      <div className="text-xs" style={{ color: 'var(--color-ink-3)' }}>{a.doctorName} · {a.time}</div>
                    </div>
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-medium ${statusClass[a.status]}`}>
                      {statusLabel[a.status]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Appointments */}
        {view === 'appointments' && (
          <div className="animate-fade-in max-w-6xl">
            <div className="flex items-center justify-between mb-6">
              <h1 className="font-display text-2xl font-semibold">Quản lý lịch hẹn</h1>
              <button className="px-4 py-2.5 rounded-xl text-sm font-semibold text-white"
                style={{ background: 'var(--color-primary)' }}>+ Tạo lịch hẹn</button>
            </div>

            {/* Status filter */}
            <div className="flex flex-wrap gap-2 mb-5">
              {(['all', 'pending', 'confirmed', 'examining', 'done', 'cancelled'] as const).map(s => (
                <button key={s} onClick={() => setStatusFilter(s)}
                  className="px-4 py-2 rounded-xl text-sm font-medium border transition-all"
                  style={{
                    borderColor: statusFilter === s ? 'var(--color-primary)' : 'var(--color-border)',
                    background: statusFilter === s ? 'var(--color-primary-50)' : 'white',
                    color: statusFilter === s ? 'var(--color-primary)' : 'var(--color-ink-2)',
                  }}>
                  {s === 'all' ? 'Tất cả' : statusLabel[s]}
                  <span className="ml-2 text-xs"
                    style={{ color: statusFilter === s ? 'var(--color-primary)' : 'var(--color-ink-4)' }}>
                    ({s === 'all' ? appointments.length : appointments.filter(a => a.status === s).length})
                  </span>
                </button>
              ))}
            </div>

            <div className="bg-white rounded-2xl border overflow-hidden"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ background: 'var(--color-surface-2)' }}>
                      {['#', 'Bệnh nhân', 'Bác sĩ', 'Chuyên khoa', 'Ngày', 'Giờ', 'Loại', 'Phí', 'Trạng thái', 'Thao tác'].map(h => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-semibold whitespace-nowrap"
                          style={{ color: 'var(--color-ink-3)', fontFamily: 'var(--font-mono)' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAppts.map(a => (
                      <tr key={a.id} className="border-t hover:bg-gray-50 transition-colors"
                        style={{ borderColor: 'var(--color-border)' }}>
                        <td className="px-4 py-3 text-xs font-mono" style={{ color: 'var(--color-ink-4)', fontFamily: 'var(--font-mono)' }}>
                          {a.id}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <img src={patients.find(p => p.id === a.patientId)?.avatar} alt={a.patientName}
                              className="w-7 h-7 rounded-lg object-cover" />
                            <span className="text-sm font-medium whitespace-nowrap">{a.patientName}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm whitespace-nowrap" style={{ color: 'var(--color-ink-2)' }}>
                          {a.doctorName.split('.').pop()?.trim() || a.doctorName}
                        </td>
                        <td className="px-4 py-3 text-sm whitespace-nowrap" style={{ color: 'var(--color-ink-3)' }}>
                          {a.specialty}
                        </td>
                        <td className="px-4 py-3 text-sm font-mono whitespace-nowrap" style={{ color: 'var(--color-ink-2)', fontFamily: 'var(--font-mono)' }}>
                          {a.date}
                        </td>
                        <td className="px-4 py-3 text-sm font-mono" style={{ color: 'var(--color-ink-2)', fontFamily: 'var(--font-mono)' }}>
                          {a.time}
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-xs">{a.type === 'online' ? '💻' : '🏥'}</span>
                        </td>
                        <td className="px-4 py-3 text-sm font-mono whitespace-nowrap" style={{ color: 'var(--color-ink-2)', fontFamily: 'var(--font-mono)' }}>
                          {(a.price / 1000).toFixed(0)}k
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2.5 py-1 rounded-lg text-xs font-medium whitespace-nowrap ${statusClass[a.status]}`}>
                            {statusLabel[a.status]}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1">
                            <button className="p-1.5 rounded hover:bg-gray-100 transition-colors text-xs">✏️</button>
                            {a.status !== 'done' && a.status !== 'cancelled' && (
                              <button className="p-1.5 rounded hover:bg-red-50 transition-colors text-xs">❌</button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Patients */}
        {view === 'patients' && (
          <div className="animate-fade-in max-w-5xl">
            <div className="flex items-center justify-between mb-6">
              <h1 className="font-display text-2xl font-semibold">Quản lý bệnh nhân</h1>
              <button className="px-4 py-2.5 rounded-xl text-sm font-semibold text-white"
                style={{ background: 'var(--color-primary)' }}>+ Thêm bệnh nhân</button>
            </div>
            <div className="flex gap-3 mb-5">
              <div className="relative flex-1 max-w-sm">
                <span className="absolute left-4 top-1/2 -translate-y-1/2">🔍</span>
                <input className="w-full pl-11 pr-4 py-3 rounded-xl border text-sm outline-none bg-white"
                  style={{ borderColor: 'var(--color-border)' }} placeholder="Tìm bệnh nhân..." />
              </div>
            </div>
            <div className="bg-white rounded-2xl border overflow-hidden"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ background: 'var(--color-surface-2)' }}>
                      {['Bệnh nhân', 'Ngày sinh', 'SĐT', 'Email', 'Nhóm máu', 'Tổng lần KH', 'Lần cuối', ''].map(h => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-semibold"
                          style={{ color: 'var(--color-ink-3)', fontFamily: 'var(--font-mono)' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {patients.map(p => (
                      <tr key={p.id} className="border-t hover:bg-gray-50 transition-colors"
                        style={{ borderColor: 'var(--color-border)' }}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-3">
                            <img src={p.avatar} alt={p.name} className="w-9 h-9 rounded-xl object-cover" />
                            <div>
                              <div className="font-medium text-sm">{p.name}</div>
                              <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>
                                {p.gender === 'male' ? 'Nam' : 'Nữ'}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-ink-2)' }}>
                          {new Date(p.dob).toLocaleDateString('vi-VN')}
                        </td>
                        <td className="px-4 py-3 text-sm font-mono" style={{ color: 'var(--color-ink-2)', fontFamily: 'var(--font-mono)' }}>
                          {p.phone}
                        </td>
                        <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-ink-3)' }}>{p.email}</td>
                        <td className="px-4 py-3">
                          <span className="px-2 py-0.5 rounded text-xs font-mono"
                            style={{ background: 'var(--color-primary-50)', color: 'var(--color-primary)', fontFamily: 'var(--font-mono)' }}>
                            {p.bloodType}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-center" style={{ color: 'var(--color-ink-2)' }}>
                          {p.appointmentCount}
                        </td>
                        <td className="px-4 py-3 text-sm" style={{ color: 'var(--color-ink-3)' }}>
                          {new Date(p.lastVisit).toLocaleDateString('vi-VN')}
                        </td>
                        <td className="px-4 py-3">
                          <button className="text-xs px-2.5 py-1 rounded-lg border"
                            style={{ borderColor: 'var(--color-border)', color: 'var(--color-primary)' }}>
                            Hồ sơ
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Doctors */}
        {view === 'doctors' && (
          <div className="animate-fade-in max-w-5xl">
            <div className="flex items-center justify-between mb-6">
              <h1 className="font-display text-2xl font-semibold">Quản lý bác sĩ</h1>
              <button className="px-4 py-2.5 rounded-xl text-sm font-semibold text-white"
                style={{ background: 'var(--color-primary)' }}>+ Thêm bác sĩ</button>
            </div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {doctors.map(d => (
                <div key={d.id} className="bg-white rounded-2xl border p-5"
                  style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                  <div className="flex items-start gap-3 mb-3">
                    <img src={d.photo} alt={d.name} className="w-14 h-14 rounded-xl object-cover" />
                    <div>
                      <div className="font-semibold text-sm">{d.name}</div>
                      <div className="text-xs" style={{ color: 'var(--color-ink-3)' }}>{d.title}</div>
                      <div className="flex items-center gap-1.5 mt-1">
                        <span className={`w-2 h-2 rounded-full inline-block ${d.available ? '' : 'opacity-40'}`}
                          style={{ background: d.available ? 'var(--color-success)' : '#9CA3AF' }} />
                        <span className="text-xs" style={{ color: d.available ? 'var(--color-success)' : 'var(--color-ink-4)' }}>
                          {d.available ? 'Đang hoạt động' : 'Tạm nghỉ'}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-xs mb-3 space-y-1" style={{ color: 'var(--color-ink-3)' }}>
                    <div>🏥 {d.specialty} · 📍 {d.branch}</div>
                    <div>⭐ {d.rating} · 🏆 {d.experience} năm KN</div>
                    <div className="font-semibold" style={{ color: 'var(--color-primary)' }}>
                      {formatCurrency(d.price)}/lượt
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="flex-1 py-2 rounded-xl text-xs border"
                      style={{ borderColor: 'var(--color-border)', color: 'var(--color-primary)' }}>
                      Xem hồ sơ
                    </button>
                    <button className="flex-1 py-2 rounded-xl text-xs border"
                      style={{ borderColor: 'var(--color-border)', color: 'var(--color-ink-2)' }}>
                      Lịch làm việc
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Specialties */}
        {view === 'specialties' && (
          <div className="animate-fade-in max-w-4xl">
            <div className="flex items-center justify-between mb-6">
              <h1 className="font-display text-2xl font-semibold">Quản lý chuyên khoa</h1>
              <button className="px-4 py-2.5 rounded-xl text-sm font-semibold text-white"
                style={{ background: 'var(--color-primary)' }}>+ Thêm chuyên khoa</button>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              {specialties.map(s => (
                <div key={s.id} className="bg-white rounded-2xl border p-5 flex items-center gap-4"
                  style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                    style={{ background: s.color + '15' }}>
                    {s.icon}
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-sm">{s.name}</div>
                    <div className="text-xs mt-0.5" style={{ color: 'var(--color-ink-3)' }}>{s.description}</div>
                    <div className="text-xs mt-1" style={{ color: s.color }}>
                      {s.doctorCount} bác sĩ
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button className="p-2 rounded-lg hover:bg-gray-100 text-sm">✏️</button>
                    <button className="p-2 rounded-lg hover:bg-red-50 text-sm">🗑️</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Services */}
        {view === 'services' && (
          <div className="animate-fade-in max-w-4xl">
            <div className="flex items-center justify-between mb-6">
              <h1 className="font-display text-2xl font-semibold">Dịch vụ & Bảng giá</h1>
              <button className="px-4 py-2.5 rounded-xl text-sm font-semibold text-white"
                style={{ background: 'var(--color-primary)' }}>+ Thêm dịch vụ</button>
            </div>
            <div className="bg-white rounded-2xl border overflow-hidden"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <table className="w-full">
                <thead>
                  <tr style={{ background: 'var(--color-surface-2)' }}>
                    {['Dịch vụ', 'Chuyên khoa', 'Thời lượng', 'Giá', 'Trạng thái', ''].map(h => (
                      <th key={h} className="px-5 py-3.5 text-left text-xs font-semibold"
                        style={{ color: 'var(--color-ink-3)', fontFamily: 'var(--font-mono)' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {services.map(s => (
                    <tr key={s.id} className="border-t hover:bg-gray-50"
                      style={{ borderColor: 'var(--color-border)' }}>
                      <td className="px-5 py-4">
                        <div className="font-medium text-sm">{s.name}</div>
                        <div className="text-xs" style={{ color: 'var(--color-ink-4)' }}>{s.description}</div>
                      </td>
                      <td className="px-5 py-4 text-sm" style={{ color: 'var(--color-ink-3)' }}>{s.specialty}</td>
                      <td className="px-5 py-4 text-sm font-mono" style={{ color: 'var(--color-ink-2)', fontFamily: 'var(--font-mono)' }}>
                        {s.duration} phút
                      </td>
                      <td className="px-5 py-4 font-semibold text-sm" style={{ color: 'var(--color-primary)' }}>
                        {formatCurrency(s.price)}
                      </td>
                      <td className="px-5 py-4">
                        <span className="px-2.5 py-1 rounded-lg text-xs badge-confirmed">Hoạt động</span>
                      </td>
                      <td className="px-5 py-4">
                        <button className="p-1.5 rounded hover:bg-gray-100 text-sm">✏️</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Schedule */}
        {view === 'schedule' && (
          <div className="animate-fade-in max-w-4xl">
            <h1 className="font-display text-2xl font-semibold mb-6">Lịch làm việc — Cơ sở Quận 1</h1>
            <div className="bg-white rounded-2xl border p-6"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr style={{ background: 'var(--color-surface-2)' }}>
                      <th className="px-4 py-3 text-left text-xs font-semibold" style={{ color: 'var(--color-ink-3)', fontFamily: 'var(--font-mono)' }}>
                        Bác sĩ
                      </th>
                      {['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN'].map(d => (
                        <th key={d} className="px-3 py-3 text-center text-xs font-semibold"
                          style={{ color: 'var(--color-ink-3)', fontFamily: 'var(--font-mono)' }}>{d}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {doctors.slice(0, 4).map(d => (
                      <tr key={d.id} className="border-t" style={{ borderColor: 'var(--color-border)' }}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <img src={d.photo} alt={d.name} className="w-8 h-8 rounded-lg object-cover" />
                            <div className="text-sm font-medium">
                              {d.name.replace(/^[A-Z]+\.[A-Z]+\.\s/, '')}
                            </div>
                          </div>
                        </td>
                        {[true, false, true, true, true, true, false].map((on, i) => (
                          <td key={i} className="px-3 py-3 text-center">
                            {on ? (
                              <div className="text-xs rounded-lg px-1.5 py-1 mx-auto"
                                style={{ background: 'var(--color-primary-50)', color: 'var(--color-primary)', maxWidth: 70, fontSize: '10px', fontFamily: 'var(--font-mono)' }}>
                                08–11h<br />13–17h
                              </div>
                            ) : (
                              <span className="text-lg">—</span>
                            )}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Reports */}
        {view === 'reports' && (
          <div className="animate-fade-in max-w-5xl">
            <h1 className="font-display text-2xl font-semibold mb-6">Thống kê & Báo cáo</h1>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              {[
                { title: 'Tổng lượt khám', value: '1,248', sub: 'Tháng 9/2026', change: '+18%', pos: true },
                { title: 'Doanh thu', value: '387.6M ₫', sub: 'Tháng 9/2026', change: '+15%', pos: true },
                { title: 'Bệnh nhân mới', value: '142', sub: 'Tháng 9/2026', change: '+23%', pos: true },
                { title: 'Tỷ lệ hủy', value: '14.3%', sub: 'Mục tiêu: <10%', change: '+2.1%', pos: false },
                { title: 'Điểm hài lòng', value: '4.8/5', sub: '389 đánh giá', change: '+0.2', pos: true },
                { title: 'Thời gian chờ TB', value: '12 phút', sub: 'Tại quầy', change: '-3 phút', pos: true },
              ].map(s => (
                <div key={s.title} className="bg-white rounded-2xl border p-5"
                  style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
                  <div className="flex justify-between items-start mb-2">
                    <div className="text-sm" style={{ color: 'var(--color-ink-3)' }}>{s.title}</div>
                    <span className="text-xs px-2 py-0.5 rounded-full font-mono"
                      style={{
                        background: s.pos ? '#D1FAE5' : '#FEE2E2',
                        color: s.pos ? '#065F46' : '#991B1B',
                        fontFamily: 'var(--font-mono)',
                      }}>
                      {s.change}
                    </span>
                  </div>
                  <div className="font-display text-2xl font-bold" style={{ color: 'var(--color-ink)' }}>{s.value}</div>
                  <div className="text-xs mt-1" style={{ color: 'var(--color-ink-4)' }}>{s.sub}</div>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-2xl border p-6"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <div className="flex items-center justify-between mb-5">
                <h2 className="font-semibold">Lượt khám theo tháng (2026)</h2>
                <button className="px-4 py-2 rounded-xl text-sm border"
                  style={{ borderColor: 'var(--color-border)', color: 'var(--color-primary)' }}>
                  Xuất báo cáo
                </button>
              </div>
              <div className="flex items-end gap-2 h-48">
                {['T1','T2','T3','T4','T5','T6','T7','T8','T9'].map((m, i) => {
                  const vals = [820, 740, 890, 960, 1020, 880, 950, 1100, 1248];
                  const max = Math.max(...vals);
                  return (
                    <div key={m} className="flex-1 flex flex-col items-center gap-2">
                      <span className="text-xs font-mono" style={{ color: 'var(--color-ink-3)', fontFamily: 'var(--font-mono)' }}>
                        {vals[i] >= 1000 ? `${(vals[i]/1000).toFixed(1)}k` : vals[i]}
                      </span>
                      <div className="w-full rounded-t-lg transition-all"
                        style={{
                          height: `${(vals[i] / max) * 80}%`,
                          background: i === 8 ? 'var(--color-primary)' : 'var(--color-primary-100)',
                        }} />
                      <span className="text-xs" style={{ color: 'var(--color-ink-4)', fontFamily: 'var(--font-mono)' }}>{m}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Audit log */}
        {view === 'audit' && (
          <div className="animate-fade-in max-w-4xl">
            <h1 className="font-display text-2xl font-semibold mb-6">Nhật ký hệ thống</h1>
            <div className="flex gap-3 mb-5">
              <input className="flex-1 max-w-sm px-4 py-2.5 rounded-xl border text-sm outline-none bg-white"
                style={{ borderColor: 'var(--color-border)' }} placeholder="🔍 Tìm kiếm nhật ký..." />
              <select className="px-3 py-2.5 rounded-xl border text-sm outline-none bg-white"
                style={{ borderColor: 'var(--color-border)' }}>
                <option>Tất cả vai trò</option>
                <option>Admin</option>
                <option>Lễ tân</option>
                <option>Bác sĩ</option>
              </select>
            </div>
            <div className="bg-white rounded-2xl border overflow-hidden"
              style={{ borderColor: 'var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              {auditLog.map((log, i) => (
                <div key={log.id} className="flex items-start gap-4 px-5 py-4 border-b last:border-0"
                  style={{ borderColor: 'var(--color-border)', background: i % 2 === 0 ? 'white' : 'var(--color-surface-2)' }}>
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center text-sm flex-shrink-0"
                    style={{
                      background: log.role === 'Admin' ? '#0F1923' : log.role === 'Bác sĩ' ? 'var(--color-primary-50)' : '#FEF3C7',
                      color: log.role === 'Admin' ? 'white' : log.role === 'Bác sĩ' ? 'var(--color-primary)' : '#92400E',
                    }}>
                    {log.role === 'Admin' ? '🔐' : log.role === 'Bác sĩ' ? '👨‍⚕️' : '🏨'}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm">{log.user}</span>
                      <span className="px-2 py-0.5 rounded text-xs"
                        style={{
                          background: log.role === 'Admin' ? '#1F2937' : 'var(--color-surface-3)',
                          color: log.role === 'Admin' ? 'white' : 'var(--color-ink-3)',
                        }}>
                        {log.role}
                      </span>
                    </div>
                    <p className="text-sm mt-1" style={{ color: 'var(--color-ink-2)' }}>{log.action}</p>
                  </div>
                  <div className="text-xs flex-shrink-0" style={{ color: 'var(--color-ink-4)', fontFamily: 'var(--font-mono)' }}>
                    {log.time}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
