export type Role = 'patient' | 'doctor' | 'admin';
export type AppointmentStatus = 'pending' | 'confirmed' | 'examining' | 'done' | 'cancelled';

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  specialtyId: string;
  title: string;
  experience: number;
  rating: number;
  reviewCount: number;
  price: number;
  photo: string;
  bio: string;
  gender: 'male' | 'female';
  available: boolean;
  languages: string[];
  education: string;
  branch: string;
}

export interface Specialty {
  id: string;
  name: string;
  icon: string;
  description: string;
  doctorCount: number;
  color: string;
}

export interface TimeSlot {
  id: string;
  time: string;
  available: boolean;
}

export interface Appointment {
  id: string;
  patientName: string;
  patientId: string;
  doctorId: string;
  doctorName: string;
  specialty: string;
  date: string;
  time: string;
  status: AppointmentStatus;
  type: 'in-person' | 'online';
  reason: string;
  symptoms: string;
  notes: string;
  service: string;
  price: number;
  branch: string;
  createdAt: string;
}

export interface Patient {
  id: string;
  name: string;
  dob: string;
  gender: 'male' | 'female';
  phone: string;
  email: string;
  address: string;
  bloodType: string;
  appointmentCount: number;
  lastVisit: string;
  avatar: string;
}

export interface Service {
  id: string;
  name: string;
  specialtyId: string;
  specialty: string;
  price: number;
  duration: number;
  description: string;
}

export interface Branch {
  id: string;
  name: string;
  address: string;
  phone: string;
  hours: string;
}

export const branches: Branch[] = [
  { id: 'b1', name: 'Cơ sở Quận 1', address: '123 Lê Lợi, Phường Bến Thành, Q.1, TP.HCM', phone: '028 3822 1234', hours: 'T2–T7: 07:30–20:00, CN: 08:00–12:00' },
  { id: 'b2', name: 'Cơ sở Quận 7', address: '45 Nguyễn Thị Thập, P.Bình Thuận, Q.7, TP.HCM', phone: '028 5413 5678', hours: 'T2–T7: 07:30–20:00, CN: 08:00–12:00' },
  { id: 'b3', name: 'Cơ sở Biên Hòa', address: '89 Đồng Khởi, P.Tân Tiến, TP.Biên Hòa, Đồng Nai', phone: '0251 384 9012', hours: 'T2–T6: 08:00–17:00' },
];

export const specialties: Specialty[] = [
  { id: 'sp1', name: 'Nội tổng quát', icon: '🫀', description: 'Khám và điều trị các bệnh nội khoa tổng quát', doctorCount: 8, color: '#0D7377' },
  { id: 'sp2', name: 'Nhi khoa', icon: '👶', description: 'Chăm sóc sức khỏe trẻ em từ sơ sinh đến 16 tuổi', doctorCount: 5, color: '#8B5CF6' },
  { id: 'sp3', name: 'Tai Mũi Họng', icon: '👂', description: 'Điều trị các bệnh vùng tai, mũi, họng và đầu cổ', doctorCount: 4, color: '#EC4899' },
  { id: 'sp4', name: 'Da liễu', icon: '🌿', description: 'Điều trị các bệnh về da, tóc, móng', doctorCount: 3, color: '#10B981' },
  { id: 'sp5', name: 'Tim mạch', icon: '❤️', description: 'Chẩn đoán và điều trị bệnh lý tim mạch', doctorCount: 4, color: '#EF4444' },
  { id: 'sp6', name: 'Xương khớp', icon: '🦴', description: 'Điều trị bệnh lý cơ xương khớp, cột sống', doctorCount: 3, color: '#F59E0B' },
  { id: 'sp7', name: 'Mắt', icon: '👁️', description: 'Chăm sóc và điều trị các bệnh lý về mắt', doctorCount: 3, color: '#3B82F6' },
  { id: 'sp8', name: 'Siêu âm - Chẩn đoán hình ảnh', icon: '🔬', description: 'Siêu âm tổng quát, X-quang, CT', doctorCount: 4, color: '#6366F1' },
];

export const doctors: Doctor[] = [
  {
    id: 'd1', name: 'TS.BS. Nguyễn Văn An', specialty: 'Nội tổng quát', specialtyId: 'sp1',
    title: 'Tiến sĩ – Bác sĩ Chuyên khoa II', experience: 18, rating: 4.9, reviewCount: 312,
    price: 300000, photo: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=200&h=200&fit=crop&auto=format',
    bio: 'Hơn 18 năm kinh nghiệm trong lĩnh vực nội khoa tổng quát, chuyên sâu về bệnh tiểu đường, huyết áp và các bệnh mãn tính.',
    gender: 'male', available: true, languages: ['Tiếng Việt', 'English'], education: 'Đại học Y Dược TP.HCM', branch: 'Cơ sở Quận 1',
  },
  {
    id: 'd2', name: 'PGS.TS. Trần Thị Bích', specialty: 'Nhi khoa', specialtyId: 'sp2',
    title: 'Phó Giáo sư – Tiến sĩ', experience: 22, rating: 4.8, reviewCount: 489,
    price: 250000, photo: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?w=200&h=200&fit=crop&auto=format',
    bio: 'Chuyên gia nhi khoa hàng đầu với 22 năm kinh nghiệm, nguyên Trưởng khoa Nhi Bệnh viện Nhi Đồng 1.',
    gender: 'female', available: true, languages: ['Tiếng Việt', 'Français'], education: 'Đại học Paris Descartes', branch: 'Cơ sở Quận 1',
  },
  {
    id: 'd3', name: 'BSCK2. Lê Hoàng Minh', specialty: 'Tim mạch', specialtyId: 'sp5',
    title: 'Bác sĩ Chuyên khoa II', experience: 15, rating: 4.7, reviewCount: 203,
    price: 400000, photo: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=200&h=200&fit=crop&auto=format',
    bio: 'Chuyên gia tim mạch can thiệp, có kinh nghiệm đặt stent và điều trị nhồi máu cơ tim cấp.',
    gender: 'male', available: true, languages: ['Tiếng Việt', 'English'], education: 'Đại học Y Hà Nội', branch: 'Cơ sở Quận 7',
  },
  {
    id: 'd4', name: 'ThS.BS. Phạm Thị Lan', specialty: 'Da liễu', specialtyId: 'sp4',
    title: 'Thạc sĩ – Bác sĩ', experience: 10, rating: 4.9, reviewCount: 567,
    price: 300000, photo: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=200&h=200&fit=crop&auto=format',
    bio: 'Bác sĩ da liễu trẻ được đào tạo tại Pháp, chuyên sâu về điều trị mụn, chăm sóc da và thẩm mỹ da.',
    gender: 'female', available: true, languages: ['Tiếng Việt', 'Français', 'English'], education: 'Université Paris Cité', branch: 'Cơ sở Quận 1',
  },
  {
    id: 'd5', name: 'TS.BS. Võ Đức Thành', specialty: 'Tai Mũi Họng', specialtyId: 'sp3',
    title: 'Tiến sĩ – Bác sĩ', experience: 16, rating: 4.6, reviewCount: 178,
    price: 300000, photo: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=200&h=200&fit=crop&auto=format',
    bio: 'Chuyên gia tai mũi họng với kỹ thuật nội soi hiện đại, điều trị viêm xoang, polyp và các bệnh lý đầu cổ.',
    gender: 'male', available: true, languages: ['Tiếng Việt'], education: 'Đại học Y Dược TP.HCM', branch: 'Cơ sở Quận 7',
  },
  {
    id: 'd6', name: 'BSCK1. Nguyễn Thị Hoa', specialty: 'Mắt', specialtyId: 'sp7',
    title: 'Bác sĩ Chuyên khoa I', experience: 8, rating: 4.8, reviewCount: 245,
    price: 280000, photo: 'https://images.unsplash.com/photo-1527613426441-4da17471b66d?w=200&h=200&fit=crop&auto=format',
    bio: 'Bác sĩ nhãn khoa chuyên điều trị tật khúc xạ, glaucoma và phẫu thuật mắt bằng laser.',
    gender: 'female', available: false, languages: ['Tiếng Việt', 'English'], education: 'Đại học Y Hà Nội', branch: 'Cơ sở Biên Hòa',
  },
];

export const services: Service[] = [
  { id: 'sv1', name: 'Khám nội tổng quát', specialtyId: 'sp1', specialty: 'Nội tổng quát', price: 300000, duration: 30, description: 'Khám và tư vấn bệnh lý nội khoa tổng quát' },
  { id: 'sv2', name: 'Khám nhi', specialtyId: 'sp2', specialty: 'Nhi khoa', price: 250000, duration: 30, description: 'Khám sức khỏe và điều trị bệnh trẻ em' },
  { id: 'sv3', name: 'Khám tai mũi họng', specialtyId: 'sp3', specialty: 'Tai Mũi Họng', price: 300000, duration: 30, description: 'Khám và điều trị bệnh lý tai mũi họng' },
  { id: 'sv4', name: 'Khám da liễu', specialtyId: 'sp4', specialty: 'Da liễu', price: 300000, duration: 30, description: 'Tư vấn và điều trị các bệnh da liễu' },
  { id: 'sv5', name: 'Khám tim mạch', specialtyId: 'sp5', specialty: 'Tim mạch', price: 400000, duration: 45, description: 'Chẩn đoán và điều trị bệnh tim mạch' },
  { id: 'sv6', name: 'Khám xương khớp', specialtyId: 'sp6', specialty: 'Xương khớp', price: 350000, duration: 30, description: 'Điều trị bệnh cơ xương khớp' },
  { id: 'sv7', name: 'Khám mắt', specialtyId: 'sp7', specialty: 'Mắt', price: 280000, duration: 30, description: 'Khám và điều trị các bệnh về mắt' },
  { id: 'sv8', name: 'Siêu âm ổ bụng', specialtyId: 'sp8', specialty: 'Siêu âm', price: 200000, duration: 20, description: 'Siêu âm tổng quát ổ bụng' },
  { id: 'sv9', name: 'Siêu âm tim', specialtyId: 'sp5', specialty: 'Tim mạch', price: 300000, duration: 30, description: 'Siêu âm tim 2D màu' },
  { id: 'sv10', name: 'Điện tim (ECG)', specialtyId: 'sp5', specialty: 'Tim mạch', price: 150000, duration: 15, description: 'Đo điện tim 12 chuyển đạo' },
];

export const patients: Patient[] = [
  { id: 'p1', name: 'Lê Văn Cường', dob: '1985-03-15', gender: 'male', phone: '0901 234 567', email: 'cuong.le@email.com', address: '12 Nguyễn Huệ, Q.1', bloodType: 'O+', appointmentCount: 7, lastVisit: '2026-09-10', avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=80&h=80&fit=crop' },
  { id: 'p2', name: 'Nguyễn Thị Mai', dob: '1990-07-22', gender: 'female', phone: '0912 345 678', email: 'mai.nguyen@email.com', address: '45 Trần Hưng Đạo, Q.5', bloodType: 'A+', appointmentCount: 3, lastVisit: '2026-09-15', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=80&h=80&fit=crop' },
  { id: 'p3', name: 'Phạm Quốc Hùng', dob: '1978-11-08', gender: 'male', phone: '0923 456 789', email: 'hung.pham@email.com', address: '78 Lê Văn Lương, Q.7', bloodType: 'B+', appointmentCount: 12, lastVisit: '2026-09-18', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop' },
  { id: 'p4', name: 'Trần Thị Thu', dob: '1995-04-30', gender: 'female', phone: '0934 567 890', email: 'thu.tran@email.com', address: '23 Hoàng Văn Thụ, Bình Thạnh', bloodType: 'AB+', appointmentCount: 2, lastVisit: '2026-09-17', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop' },
  { id: 'p5', name: 'Hoàng Minh Tuấn', dob: '1988-09-12', gender: 'male', phone: '0945 678 901', email: 'tuan.hoang@email.com', address: '56 Phan Xích Long, Phú Nhuận', bloodType: 'O-', appointmentCount: 5, lastVisit: '2026-09-16', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=80&h=80&fit=crop' },
];

export const appointments: Appointment[] = [
  { id: 'a001', patientName: 'Lê Văn Cường', patientId: 'p1', doctorId: 'd1', doctorName: 'TS.BS. Nguyễn Văn An', specialty: 'Nội tổng quát', date: '2026-09-19', time: '09:00', status: 'confirmed', type: 'in-person', reason: 'Kiểm tra huyết áp định kỳ', symptoms: 'Thường xuyên đau đầu, chóng mặt buổi sáng', notes: '', service: 'Khám nội tổng quát', price: 300000, branch: 'Cơ sở Quận 1', createdAt: '2026-09-14' },
  { id: 'a002', patientName: 'Nguyễn Thị Mai', patientId: 'p2', doctorId: 'd4', doctorName: 'ThS.BS. Phạm Thị Lan', specialty: 'Da liễu', date: '2026-09-19', time: '10:30', status: 'examining', type: 'in-person', reason: 'Điều trị mụn trứng cá', symptoms: 'Mụn viêm nhiều ở má và trán', notes: 'Đang dùng retinol 0.025%', service: 'Khám da liễu', price: 300000, branch: 'Cơ sở Quận 1', createdAt: '2026-09-12' },
  { id: 'a003', patientName: 'Phạm Quốc Hùng', patientId: 'p3', doctorId: 'd3', doctorName: 'BSCK2. Lê Hoàng Minh', specialty: 'Tim mạch', date: '2026-09-19', time: '14:00', status: 'pending', type: 'in-person', reason: 'Khó thở khi gắng sức', symptoms: 'Tức ngực, khó thở khi leo cầu thang', notes: '', service: 'Khám tim mạch', price: 400000, branch: 'Cơ sở Quận 7', createdAt: '2026-09-17' },
  { id: 'a004', patientName: 'Trần Thị Thu', patientId: 'p4', doctorId: 'd2', doctorName: 'PGS.TS. Trần Thị Bích', specialty: 'Nhi khoa', date: '2026-09-19', time: '15:30', status: 'confirmed', type: 'online', reason: 'Bé sốt, ho', symptoms: 'Sốt 38.5°C, ho khan 3 ngày', notes: '', service: 'Khám nhi', price: 250000, branch: 'Cơ sở Quận 1', createdAt: '2026-09-18' },
  { id: 'a005', patientName: 'Hoàng Minh Tuấn', patientId: 'p5', doctorId: 'd5', doctorName: 'TS.BS. Võ Đức Thành', specialty: 'Tai Mũi Họng', date: '2026-09-18', time: '08:30', status: 'done', type: 'in-person', reason: 'Viêm xoang mãn tính', symptoms: 'Nghẹt mũi, chảy mũi, đau đầu âm ỉ', notes: 'Đã nội soi, kê augmentin 625mg x 10 ngày', service: 'Khám tai mũi họng', price: 300000, branch: 'Cơ sở Quận 7', createdAt: '2026-09-13' },
  { id: 'a006', patientName: 'Lê Văn Cường', patientId: 'p1', doctorId: 'd3', doctorName: 'BSCK2. Lê Hoàng Minh', specialty: 'Tim mạch', date: '2026-09-20', time: '09:30', status: 'confirmed', type: 'in-person', reason: 'Điện tim định kỳ', symptoms: '', notes: '', service: 'Điện tim (ECG)', price: 150000, branch: 'Cơ sở Quận 7', createdAt: '2026-09-16' },
  { id: 'a007', patientName: 'Nguyễn Thị Mai', patientId: 'p2', doctorId: 'd1', doctorName: 'TS.BS. Nguyễn Văn An', specialty: 'Nội tổng quát', date: '2026-09-15', time: '11:00', status: 'cancelled', type: 'in-person', reason: 'Kiểm tra sức khỏe tổng quát', symptoms: 'Mệt mỏi kéo dài', notes: 'Bệnh nhân hủy do bận công việc', service: 'Khám nội tổng quát', price: 300000, branch: 'Cơ sở Quận 1', createdAt: '2026-09-10' },
];

export const timeSlots: TimeSlot[] = [
  { id: 't1', time: '07:30', available: false },
  { id: 't2', time: '08:00', available: true },
  { id: 't3', time: '08:30', available: false },
  { id: 't4', time: '09:00', available: true },
  { id: 't5', time: '09:30', available: true },
  { id: 't6', time: '10:00', available: false },
  { id: 't7', time: '10:30', available: true },
  { id: 't8', time: '11:00', available: true },
  { id: 't9', time: '13:30', available: true },
  { id: 't10', time: '14:00', available: false },
  { id: 't11', time: '14:30', available: true },
  { id: 't12', time: '15:00', available: true },
  { id: 't13', time: '15:30', available: false },
  { id: 't14', time: '16:00', available: true },
  { id: 't15', time: '16:30', available: true },
  { id: 't16', time: '17:00', available: false },
];

export const statusLabel: Record<AppointmentStatus, string> = {
  pending: 'Chờ xác nhận',
  confirmed: 'Đã xác nhận',
  examining: 'Đang khám',
  done: 'Hoàn tất',
  cancelled: 'Đã hủy',
};

export const statusClass: Record<AppointmentStatus, string> = {
  pending: 'badge-pending',
  confirmed: 'badge-confirmed',
  examining: 'badge-examining',
  done: 'badge-done',
  cancelled: 'badge-cancelled',
};

export const formatCurrency = (amount: number) =>
  new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);

export const formatDate = (dateStr: string) => {
  const d = new Date(dateStr);
  return d.toLocaleDateString('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric' });
};

export const auditLog = [
  { id: 1, user: 'Admin Hà', role: 'Admin', time: '16:05 — 18/09/2026', action: 'Hủy lịch khám #a007 (Nguyễn Thị Mai)' },
  { id: 2, user: 'Lễ tân Lan', role: 'Lễ tân', time: '15:32 — 18/09/2026', action: 'Cập nhật lịch làm việc BS. Nguyễn Văn An tuần 39' },
  { id: 3, user: 'Admin Hà', role: 'Admin', time: '14:20 — 18/09/2026', action: 'Thêm bác sĩ mới: ThS.BS. Đinh Quang Khải — Xương khớp' },
  { id: 4, user: 'Lễ tân Lan', role: 'Lễ tân', time: '09:15 — 18/09/2026', action: 'Check-in bệnh nhân Hoàng Minh Tuấn — lịch #a005' },
  { id: 5, user: 'BS. Trần Thị Bích', role: 'Bác sĩ', time: '08:40 — 17/09/2026', action: 'Xác nhận lịch khám #a004 (Trần Thị Thu — online)' },
];
